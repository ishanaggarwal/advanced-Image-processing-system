package controller;

import java.io.IOException;
import java.util.List;

import view.ConsoleView;

/**
 * A class to process command with brighten image.
 */

public class BrightenCommand implements ICommand {
  @Override
  public void execute(Command command, ImageController controller, ConsoleView view)
          throws IOException {
    List<String> args = command.getArguments();
    if (args.size() < 3) {
      view.display(CommandGuide.BRIGHTEN.getDescription());
      return;
    }
    try {
      double v1 = Double.parseDouble(args.get(0));
      controller.brighten((int) v1, args.get(1), args.get(2));
    } catch (Exception e) {
      view.display("Error processing the image: " + e.getMessage());
    }
  }
}
