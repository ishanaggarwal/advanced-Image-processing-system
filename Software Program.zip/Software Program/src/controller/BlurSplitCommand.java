package controller;

import java.io.IOException;
import java.util.List;

import view.ConsoleView;

/**
 * A class implements specific Command.
 */

public class BlurSplitCommand implements ICommand {
  @Override
  public void execute(Command command, ImageController controller, ConsoleView view)
          throws IOException {
    List<String> args = command.getArguments();
    if (args.size() < 3) {
      view.display(CommandGuide.BLUR_SPLIT.getDescription());
      return;
    }

    try {
      double v1 = Double.parseDouble(args.get(2));
      controller.blurSplit(
              args.get(0),
              args.get(1),
              (int) v1);
    } catch (Exception e) {
      view.display("Error loading the image: " + e.getMessage());
    }
  }
}