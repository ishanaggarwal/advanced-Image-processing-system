package controller;


/**
 * An emu class to store command guides string.
 */

public enum CommandGuide {

  MENU("Welcome to image process."),
  DARKEN("darken <num> <oldImage> <newImage>"
      + " – Darken degree of darkens of an image."),
  LOAD("load <path> <name>"
      + " - Load an image from a path and assign it a name."),
  SAVE("save <path> <name> "
      + "- Save the image with the given name to the specified path."),
  RED_COMPONENT("red-component <oldImage> <newImage> "
      + "- Extract the red component of the image."),
  GREEN_COMPONENT("green-component <oldImage> <newImage>"
      + " - Extract the green component of the image."),
  BLUE_COMPONENT("blue-component <oldImage> <newImage>"
      + " - Extract the blue component of the image."),
  VALUE_COMPONENT("value-component <oldImage> <newImage> "
      + "- Extract the value component of the image."),
  INTENSITY_COMPONENT("intensity-component <oldImage> <newImage>"
      + " - Extract the intensity component of the image."),
  LUMA_COMPONENT("luma-component <oldImage> <newImage> " +
      "- Extract the luma component of the image."),
  HORIZONTAL_FLIP("horizontal-flip <oldImage> <newImage> "
      + "- Flip the image horizontally."),
  VERTICAL_FLIP("vertical-flip <oldImage> <newImage> "
      + "- Flip the image vertically."),
  BRIGHTEN("brighten <value> <oldImage> <newImage> "
      + "- Brighten the image by the given value."),
  RGB_SPLIT("rgb-split <oldImage> <imageR> <imageG> <imageB> "
      + " - Split the image into its RGB components."),
  RGB_COMBINE("rgb-combine <imageR> <imageG> <imageB> <newImage> "
      + " - Combine RGB components into a single image."),
  BLUR("blur <oldImage> <newImage> - Apply a blur effect to the image."),
  SHARPEN("sharpen <oldImage> <newImage> - Sharpen the image."),
  SEPIA("sepia <oldImage> <newImage> - Convert the image to sepia tone."),
  DITHER("dither <oldImage> <newImage> - Dither the image"),
  RUN_SCRIPT("run <scriptFilePath>  <image key> "
      + " - Execute a script containing a sequence of commands."),
  HELP("help - Display this help message."),
  QUIT("quit - Quit the application."),
  LEVEL_ADJUST_SPLIT("level-adjust-split <num b> <num m> <num w>"
      + " <oldImage> <newImage> <num split>"
      + "- Level adjust split of an image."),
  HISTOGRAM("histogram <oldimage> <newimage>"
      + "- Histogram of image"),
  COLOR_CORRECT("color-correct <oldimage> <newimage>"
      + "- Correct coloring of image"),
  COMPRESSION("compression <num>  <oldimage> <newimage>"
      + " - Compression to image"),

  CORRECT_CORRECT_SPLIT("color-correct-split <oldimage> <newimage> <num>"
      + "- Correct coloring split of image"),

  LEVEL_ADJUST("level-adjust <num b> <num m> <num 2> <oldImage> <newImage>"
      + "- Level adjust of an image."),
  BLUR_SPLIT("blur-split <oldimage> <newimage> <num>"
      + "- Blur split image"),

  SHARPEN_SPLIT("sharpen-split <oldimage> <newimage> <num>"
      + "- Sharpen split image"),

  SEPIA_SPLIT("sepia-split <oldimage> <newimage> <num>"
      + "- Sepia split image"),

  DITHER_SPLIT("dither <oldImage> <newImage> <num> - Dither the image in a split view"),

  GREYSCALE_SPLIT("greyscale-split <oldimage> <newimage> <num>"
      + " - greyScale split image");

  private final String description;

  /**
   * String of each guide object.
   *
   * @param description each command guide.
   */

  CommandGuide(String description) {
    this.description = description;
  }

  /**
   * Get help for all command description.
   */

  public static String getHelpDescription() {
    StringBuilder helpDescription = new StringBuilder();
    for (CommandGuide command : CommandGuide.values()) {
      helpDescription.append(command.getDescription()).append("\n");
    }
    return helpDescription.toString();
  }

  /**
   * Get each command description in string.
   */

  public String getDescription() {
    return description;
  }
}

