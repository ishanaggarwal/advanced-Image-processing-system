package controller;

import java.io.IOException;
import java.util.List;

import view.ConsoleView;

/**
 * A class represents run script command  to process image.
 */

public class RunScriptCommand implements ICommand {
  @Override
  public void execute(Command command, ImageController controller, ConsoleView view)
          throws IOException {
    List<String> args = command.getArguments();
    if (args.size() < 2) {
      view.display(CommandGuide.RUN_SCRIPT.getDescription());
      return;
    }
    try {
      controller.runScript(args.get(0));
      view.display("running" + " " + args.get(0));
    } catch (Exception e) {
      view.display("Error running script: " + e.getMessage());
    }
  }
}
