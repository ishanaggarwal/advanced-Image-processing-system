package controller;

import java.io.IOException;
import java.util.List;

import view.ConsoleView;

/**
 * A class to do blue command process.
 */

public class BlurCommand implements ICommand {
  @Override
  public void execute(Command command, ImageController controller, ConsoleView view)
          throws IOException {
    List<String> args = command.getArguments();
    if (args.size() < 2) {
      view.display(CommandGuide.BLUR.getDescription());
      return;
    }
    try {
      controller.blueComponent(args.get(0), args.get(1));
    } catch (Exception e) {
      view.display("Error processing the image: " + e.getMessage());
    }
  }
}
