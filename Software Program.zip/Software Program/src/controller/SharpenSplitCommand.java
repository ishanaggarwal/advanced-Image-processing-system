package controller;


import java.io.IOException;
import java.util.List;

import view.ConsoleView;

/**
 * A class implements specific Command.
 */

public class SharpenSplitCommand implements ICommand {
  @Override
  public void execute(Command command, ImageController controller, ConsoleView view)
          throws IOException {
    List<String> args = command.getArguments();
    if (args.size() < 3) {
      view.display(CommandGuide.SHARPEN_SPLIT.getDescription());
      return;
    }

    try {
      double v1 = Double.parseDouble(args.get(2));
      controller.sharpenSplit(
              args.get(0),
              args.get(1),
              (int) v1);
    } catch (Exception e) {
      view.display("Error loading the image: " + e.getMessage());
    }
  }
}