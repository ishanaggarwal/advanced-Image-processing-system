package controller;

import java.io.IOException;

import view.ConsoleView;

/**
 * A class represents quit command  to process image.
 */

public class QuitCommand implements ICommand {
  @Override
  public void execute(Command command, ImageController controller, ConsoleView view)
          throws IOException {
    view.display("Quiting.");
    controller.quit();
  }
}
