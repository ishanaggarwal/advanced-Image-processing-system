package controller;

import java.io.IOException;
import java.util.List;

import view.ConsoleView;

/**
 * A class implements specific Command.
 */

public class ColorCorrectCommand implements ICommand {
  @Override
  public void execute(Command command, ImageController controller, ConsoleView view)
          throws IOException {
    List<String> args = command.getArguments();
    if (args.size() < 2) {
      view.display(CommandGuide.COLOR_CORRECT.getDescription());
      return;
    }

    try {
      controller.colorCorrect(
              args.get(0),
              args.get(1));
    } catch (Exception e) {
      view.display("Error loading the image: " + e.getMessage());
    }
  }
}
