package controller;

import java.io.IOException;

import view.ConsoleView;

/**
 * Interface to encapsulate the logic for executing a command.
 */

public interface ICommand {

  /**
   * Execute command.
   *
   * @param command    command input
   * @param controller controller
   * @param view       view
   */

  void execute(Command command, ImageController controller, ConsoleView view) throws IOException;
}
