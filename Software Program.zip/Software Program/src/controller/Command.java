package controller;

import java.util.List;

/**
 * A class to represent a command and its args.
 * Helper to contain input and output in command pattern design.
 */

public class Command {
  private final String action;
  private final List<String> arguments;

  /**
   * Read user input as Command.
   *
   * @param action    command action
   * @param arguments command condition
   */

  public Command(String action, List<String> arguments) {
    this.action = action.toLowerCase();
    this.arguments = arguments;
  }

  /**
   * Get command action.
   *
   * @return command action string
   */

  public String getAction() {
    return action;
  }

  /**
   * Get command condition action.
   *
   * @return command action condition string
   */

  public List<String> getArguments() {
    return arguments;
  }
}
