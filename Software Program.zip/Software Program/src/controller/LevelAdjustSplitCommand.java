package controller;

import java.io.IOException;
import java.util.List;

import view.ConsoleView;

/**
 * A class implements specific Command.
 */

public class LevelAdjustSplitCommand implements ICommand {
  @Override
  public void execute(Command command, ImageController controller, ConsoleView view)
          throws IOException {
    List<String> args = command.getArguments();
    if (args.size() < 6) {
      view.display(CommandGuide.LEVEL_ADJUST_SPLIT.getDescription());
      return;
    }

    try {
      double v1 = Double.parseDouble(args.get(0));
      double v2 = Double.parseDouble(args.get(1));
      double v3 = Double.parseDouble(args.get(2));
      double v4 = Double.parseDouble(args.get(5));
      controller.levelAdjSplit((int) v1,
              (int) v2,
              (int) v3,
              args.get(3),
              args.get(4),
              (int) v4);
    } catch (Exception e) {
      view.display("Error loading the image: " + e.getMessage());
    }
  }
}
