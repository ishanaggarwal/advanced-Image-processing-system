package controller;

import java.io.IOException;
import java.util.List;

import view.ConsoleView;

/**
 * A class implements specific Command.
 */

public class CompressionCommand implements ICommand {
  @Override
  public void execute(Command command, ImageController controller, ConsoleView view)
          throws IOException {
    List<String> args = command.getArguments();
    if (args.size() < 3) {
      view.display(CommandGuide.COMPRESSION.getDescription());
      return;
    }

    try {
      double v1 = Double.parseDouble(args.get(0));
      controller.compression((int) v1,
              args.get(1),
              args.get(2));
    } catch (Exception e) {
      view.display("Error loading the image: " + e.getMessage());
    }
  }
}