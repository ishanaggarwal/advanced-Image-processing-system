package controller;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import imageio.ImageUtil;
import model.FilePathHandle;
import model.Image;
import model.ImageManipulator;
import view.ConsoleView;
import view.DisplayHistogram;

/**
 * Class to process commands and control the update of model/view.
 */


public class ImageController implements ImageControllerInterface {

  /**
   * This is the image application controller.
   */

  private final Map<String, Image> map;
  private final ImageManipulator imageManipulator;
  private final ConsoleView view;
  private final Map<String, ICommand> commandMap;

  private final ImageUtil imageLoaderSaver = new ImageUtil();

  /**
   * Constructor for ImageController.
   *
   * @param imageManipulator The image manipulator model.
   * @param view             The console view.
   */

  public ImageController(ImageManipulator imageManipulator, ConsoleView view) {

    this.imageManipulator = imageManipulator;
    this.view = view;
    this.map = new HashMap<>();
    this.commandMap = new HashMap<>();
    initializeCommands();
  }

  /**
   * This is a other constructor of the Swing.
   * @param imageManipulator the image manipulator
   */
  public ImageController(ImageManipulator imageManipulator) {
    this.imageManipulator = imageManipulator;
    this.view = null;
    this.map = new HashMap<>();
    this.commandMap = new HashMap<>();
    initializeCommands();
  }


  /**
   * Helper to get map of command and function.
   */

  private void initializeCommands() {

    commandMap.put("load", new LoadCommand());
    commandMap.put("save", new SaveCommand());
    commandMap.put("red-component", new RedComponentCommand());
    commandMap.put("green-component", new GreenComponentCommand());
    commandMap.put("blue-component", new BlueComponentCommand());
    commandMap.put("vertical-flip", new VerticalFlipCommand());
    commandMap.put("horizontal-flip", new HorizontalFlipCommand());
    commandMap.put("brighten", new BrightenCommand());
    commandMap.put("blur", new BlurCommand());
    commandMap.put("sharpen", new SharpenCommand());
    commandMap.put("darken", new DarkenCommand());
    commandMap.put("sepia", new SepiaCommand());
    commandMap.put("dither", new DitherCommand());
    commandMap.put("value-component", new ValueComponentCommand());
    commandMap.put("intensity-component", new IntensityComponentCommand());
    commandMap.put("luma-component", new LumaComponentCommand());
    commandMap.put("rgb-split", new RGBSplitCommand());
    commandMap.put("rgb-combine", new RGBCombineCommand());
    commandMap.put("run", new RunScriptCommand());
    commandMap.put("help", new HelpCommand());
    commandMap.put("quit", new QuitCommand());
    commandMap.put("compression", new CompressionCommand());
    commandMap.put("color-correct", new ColorCorrectCommand());
    commandMap.put("histogram", new HistogramCommand());
    commandMap.put("level-adjust", new LevelAdjustCommand());
    commandMap.put("blur-split", new BlurSplitCommand());
    commandMap.put("sharpen-split", new SharpenSplitCommand());
    commandMap.put("sepia-split", new SepiaSplitCommand());
    commandMap.put("dither-split", new DitherSplitCommand());
    commandMap.put("greyscale-split", new GreyScaleSplitCommand());
    commandMap.put("color-correct-split", new ColorCorrectSplitCommand());
    commandMap.put("level-adjust-split", new LevelAdjustSplitCommand());

  }


  /**
   * Command to execute.
   *
   * @param command command to execute
   * @param view    view for user
   */

  @Override
  public void executeCommand(Command command, ConsoleView view) throws IOException {
    ICommand commandInterface = commandMap.get(command.getAction());
    if (commandInterface != null) {
      commandInterface.execute(command, this, view);
    } else {
      view.display("Unknown command: " + command.getAction());
    }
  }


  /**
   * Helper to quit program.
   */
  @Override
  public void quit() {
    System.exit(0);
  }

  /**
   * Helper to run program.
   */
  @Override
  public void run() throws IOException {
    view.display(CommandGuide.MENU.getDescription());
    while (true) {
      try {
        String inputLine = view.readLine();
        // Exit the loop if EOF
        if (inputLine == null) {
          break;
        }

        String[] parts = inputLine.split(" ");
        if (parts.length == 0) {
          // Skip empty lines
          continue;
        }

        String action = parts[0];
        Command command = new Command(action,
                Arrays.asList(parts).subList(1, parts.length));

        executeCommand(command, view);
      } catch (IOException e) {
        view.display("Error reading input: " + e.getMessage());
      } catch (Exception e) {
        view.display("Error processing command: " + e.getMessage());
      }
    }
  }

  /**
   * This class is for the get the buffered Image for the GUI.
   *
   * @param oldImage the old image name
   * @return the buffered image of the image.
   */
  @Override
  public BufferedImage getBufferedImage(String oldImage) {
    Image oldImg = map.get(oldImage);
    if (oldImg == null) {
      return new BufferedImage(100,600,1);
    }
    BufferedImage image = imageLoaderSaver.getBufferedImage(oldImg);

    return imageLoaderSaver.getBufferedImage(oldImg);

  }

  /**
   * This is the get buffered Image for the histogram.
   *
   * @param oldImage the old Image
   * @return the buffered Image of the histogram
   */
  @Override
  public BufferedImage getHistogram(String oldImage) {
    Image oldImg = map.get(oldImage);
    if (oldImg == null) {
      return new BufferedImage(100,600,1);
    }
    // generates histogram data
    int[][] data = imageManipulator.generateData(oldImg);
    DisplayHistogram hist = new DisplayHistogram();
    BufferedImage image = hist.createHistogramImage(data);

    return image;
  }

  /**
   * This method is for split the red component.
   *
   * @param oldImage the old image
   * @param newImage the new image
   * @param split    the percentage of split
   */
  @Override
  public void redComponentSplit(String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.imageSplit(oldImg, split, "red");
    map.put(newImage, newImg);
  }

  /**
   * Split the green component.
   *
   * @param oldImage the old image
   * @param newImage the new image
   * @param split    the percentage of split
   */
  @Override
  public void greenComponentSplit(String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.imageSplit(oldImg, split, "green");
    map.put(newImage, newImg);
  }

  /**
   * This method is for split the blue component.
   *
   * @param oldImage the old image
   * @param newImage the new image
   * @param split    the percentage of split
   */
  @Override
  public void blueComponentSplit(String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.imageSplit(oldImg, split, "blue");
    map.put(newImage, newImg);
  }

  /**
   * This method is for split the flip horizonal.
   *
   * @param oldImage the old image
   * @param newImage the new image
   * @param split    the percentage of split
   */
  @Override
  public void flipHorizonalSplit(String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.imageSplit(oldImg, split, "flip Horizontal");
    map.put(newImage, newImg);
  }

  /**
   * This method is for split the flip vertical.
   *
   * @param oldImage the old image
   * @param newImage the new image
   * @param split    the percentage of split
   */
  @Override
  public void flipVerticalSplit(String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.imageSplit(oldImg, split, "flip Vertical");
    map.put(newImage, newImg);
  }

  /**
   * This method is for split the compression image.
   *
   * @param oldImage   the old image
   * @param newImage   the new image
   * @param split      the percentage of split
   * @param percentage the percentage of compression
   */
  @Override
  public void compressionSplit(String oldImage, String newImage, int split, int percentage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.compressionSplit(oldImg, split, "compression", percentage);
    map.put(newImage, newImg);
  }

  /**
   * This method is for split the luma.
   *
   * @param oldImage the old image
   * @param newImage the new image
   * @param split    the percentage of split
   */
  @Override
  public void lumaSplit(String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.imageSplit(oldImg, split, "luma");
    map.put(newImage, newImg);
  }

  @Override
  public void runScript(String scriptFilePath) throws IOException {
    scriptFilePath = FilePathHandle.getAbsolutePath(scriptFilePath);
    try (BufferedReader reader = new BufferedReader(new FileReader(scriptFilePath))) {
      String line;
      while ((line = reader.readLine()) != null) {
        line = line.trim();
        if (line.isEmpty() || line.startsWith("#")) {
          // Skip empty lines and comments
          continue;
        }

        String[] parts = line.split(" ");
        String action = parts[0];
        List<String> arguments = Arrays.asList(parts).subList(1, parts.length);
        Command command = new Command(action, arguments);
        this.executeCommand(command, view);
      }
    } catch (IOException e) {
      if (view != null) {
        view.display("Error running script: " + e.getMessage());
      } else {
        System.out.println("Error running script: " + e.getMessage());
      }
    }
  }

  /**
   * Load image function.
   *
   * @param pathname : image path.
   * @param key      : image name.
   */

  @Override
  public void load(String pathname, String key) {
    Image image = new Image();
    image = imageManipulator.loadImagePath(pathname);
    map.put(key, image);

  }

  // below are controller actions to process image.

  @Override
  public void save(String path, String name) throws IOException {
    Image image = new Image();
    String filename = path.split("\\.")[0];
    String extend = path.split("\\.")[1];
    image = map.get(name);
    imageManipulator.saveImageByPath(path, extend, image);
  }


  @Override
  public void redComponent(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.redComponent(oldImg);
    map.put(newImage, newImg);
  }


  @Override
  public void greenComponent(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.greenComponent(oldImg);
    map.put(newImage, newImg);
  }

  @Override
  public void blueComponent(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.blueComponent(oldImg);
    map.put(newImage, newImg);
  }


  @Override
  public void valueComponent(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.valueComponent(oldImg);
    map.put(newImage, newImg);
  }


  @Override
  public void intensityComponent(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.intensityComponent(oldImg);
    map.put(newImage, newImg);
  }


  @Override
  public void lumaComponent(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.lumaComponent(oldImg);
    map.put(newImage, newImg);
  }


  @Override
  public void filpHorizontally(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.filpHorizontally(oldImg);
    map.put(newImage, newImg);

  }


  @Override
  public void filpVertically(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.filpVertically(oldImg);
    map.put(newImage, newImg);
  }

  @Override
  public void brighten(int num, String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.brighten(oldImg, num);
    map.put(newImage, newImg);
    //System.out.println("Saving file to: " + path);

  }

  @Override
  public void rgbSplit(String oldImage, String imageR, String imageG, String imageB) {
    Image oldImg = map.get(oldImage);
    Image[] newImg = imageManipulator.splitToThreeColorImages(oldImg);
    map.put(imageR, newImg[0]);
    map.put(imageG, newImg[1]);
    map.put(imageB, newImg[2]);
  }


  @Override
  public void rgbCombine(String imageR, String imageG, String imageB, String newImage) {
    Image oldImgR = map.get(imageR);
    Image oldImgG = map.get(imageG);
    Image oldImgB = map.get(imageB);
    Image newImg = imageManipulator.combineToOneImage(oldImgR, oldImgG, oldImgB);
    map.put(newImage, newImg);
  }


  @Override
  public void darken(int num, String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.darken(oldImg, num);
    map.put(newImage, newImg);
  }


  @Override
  public void blur(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.blur(oldImg);
    map.put(newImage, newImg);
  }

  @Override
  public void sharpen(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.sharpen(oldImg);
    map.put(newImage, newImg);
  }


  @Override
  public void convertSepia(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.convertSepia(oldImg);
    map.put(newImage, newImg);
  }

  @Override
  public void dither(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.dither(oldImg);
    map.put(newImage, newImg);
  }


  @Override
  public void compression(int percentage, String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.compression(percentage, oldImg);
    map.put(newImage, newImg);
  }


  @Override
  public void blurSplit(String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.imageSplit(oldImg, split, "blur");
    map.put(newImage, newImg);
  }

  @Override
  public void sharpenSplit(String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.imageSplit(oldImg, split, "sharpen");
    map.put(newImage, newImg);
  }

  @Override
  public void sepiaSplit(String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.imageSplit(oldImg, split, "sepia");
    map.put(newImage, newImg);
  }


  @Override
  public void ditherSplit(String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.imageSplit(oldImg, split, "dither");
    map.put(newImage, newImg);
  }

  @Override
  public void greyscaleSplit(String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.imageSplit(oldImg, split, "grey");
    map.put(newImage, newImg);
  }

  @Override
  public void levelAdj(int b, int m, int w, String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.levelAdjustment(oldImg, b, m, w);
    map.put(newImage, newImg);
  }

  @Override
  public void histogram(String oldImage, String newImage) throws IOException {
    Image oldImg = map.get(oldImage);
    // generates histogram data
    int[][] data = imageManipulator.generateData(oldImg);
    DisplayHistogram hist = new DisplayHistogram();

    BufferedImage histogramImage = hist.createHistogramImage(data);

    // Save the histogram image if 'newImage' is provided
    if (newImage != null && !newImage.isEmpty()) {
      saveHistogramImage(histogramImage, FilePathHandle.getAbsolutePath(newImage));
    }
  }


  /**
   * Helper to save histogram.
   *
   * @param image histogram image
   * @param path  path of image
   * @throws IOException error when saving
   */

  private void saveHistogramImage(BufferedImage image, String path) throws IOException {
    File outputFile = new File(path);
    ImageIO.write(image, "png", outputFile);
    view.display("Histogram saved to " + path);
  }

  @Override
  public void colorCorrect(String oldImage, String newImage) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.correction(oldImg);
    map.put(newImage, newImg);
  }

  @Override
  public void levelAdjSplit(int b, int m, int w, String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator
            .levelAdjustmentSplit(oldImg, split, "adjustment", b, m, w);
    map.put(newImage, newImg);
  }

  /**
   * color correct.
   *
   * @param oldImage the origin image
   * @param newImage the new image after split
   * @param split    the percentage we want to split.
   */


  @Override
  public void colorCorrectSplit(String oldImage, String newImage, int split) {
    Image oldImg = map.get(oldImage);
    Image newImg = imageManipulator.imageSplit(oldImg, split, "correction");
    map.put(newImage, newImg);
  }


}

