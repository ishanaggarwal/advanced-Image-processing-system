package controller;

import java.awt.image.BufferedImage;
import java.io.IOException;

import view.ConsoleView;

/**
 * This is an interface class for the controller to do actions to image.
 */
public interface ImageControllerInterface {


  /**
   * Command to execute.
   *
   * @param command command to execute
   * @param view    view for user
   */
  void executeCommand(Command command, ConsoleView view) throws IOException;

  /**
   * Load image.
   *
   * @param path : image path.
   * @param name : image name.
   */
  void load(String path, String name);

  /**
   * Save image.
   *
   * @param path : image path.
   * @param name : image name.
   * @throws IOException : throw exception if file save error.
   */

  void save(String path, String name) throws IOException;

  /**
   * Red component of image.
   *
   * @param oldImage : read image.
   * @param newImage : output image.
   */

  void redComponent(String oldImage, String newImage);

  /**
   * green component of image.
   *
   * @param oldImage : read image.
   * @param newImage : output image.
   */


  void greenComponent(String oldImage, String newImage);

  /**
   * Blue component of image.
   *
   * @param oldImage : read image.
   * @param newImage : output image.
   */

  void blueComponent(String oldImage, String newImage);

  /**
   * value component of greyscale image.
   *
   * @param oldImage : read image.
   * @param newImage : output image.
   */

  void valueComponent(String oldImage, String newImage);

  /**
   * intensity component of greyscale image.
   *
   * @param oldImage : read image.
   * @param newImage : output image.
   */

  void intensityComponent(String oldImage, String newImage);

  /**
   * luma component of greyscale image.
   *
   * @param oldImage : read image.
   * @param newImage : output image.
   */

  void lumaComponent(String oldImage, String newImage);

  /**
   * flip horizontally to image.
   *
   * @param oldImage : read image.
   * @param newImage : output image.
   */

  void filpHorizontally(String oldImage, String newImage);


  /**
   * flip vertically to image.
   *
   * @param oldImage : read image.
   * @param newImage : output image.
   */

  void filpVertically(String oldImage, String newImage);


  /**
   * brighten to image.
   *
   * @param oldImage : read image.
   * @param newImage : output image.
   */

  void brighten(int num, String oldImage, String newImage);


  /**
   * split rgb to image.
   *
   * @param oldImage read image.
   * @param imageR   red image.
   * @param imageG   green image.
   * @param imageB   blue image.
   */

  void rgbSplit(String oldImage, String imageR, String imageG, String imageB);

  /**
   * rgb combine  to image.
   *
   * @param oldImage read image.
   * @param imageR   red image.
   * @param imageG   green image.
   * @param imageB   blue image.
   */

  void rgbCombine(String imageR, String imageG, String imageB, String oldImage);

  /**
   * Run script file.
   *
   * @param scriptFilePath : file path.
   * @throws IOException : throw exception in error of reading file.
   */

  void runScript(String scriptFilePath) throws IOException;

  /**
   * darken image.
   *
   * @param num      : degree of darkens.
   * @param oldImage : read image
   * @param newImage : output image.
   */

  void darken(int num, String oldImage, String newImage);

  /**
   * blur image.
   *
   * @param oldImage : read image
   * @param newImage : output image.
   */


  void blur(String oldImage, String newImage);

  /**
   * sharpen image.
   *
   * @param oldImage : read image
   * @param newImage : output image.
   */


  void sharpen(String oldImage, String newImage);

  /**
   * sepia image.
   *
   * @param oldImage : read image
   * @param newImage : output image.
   */


  void convertSepia(String oldImage, String newImage);

  /**
   * dither image.
   *
   * @param oldImage : read image
   * @param newImage : output image.
   */


  void dither(String oldImage, String newImage);

  /**
   * compression image.
   *
   * @param percentage percentage we want to compression
   * @param oldImage   read image
   * @param newImage   output image
   */
  void compression(int percentage, String oldImage, String newImage);

  /**
   * split image for blur.
   *
   * @param oldImage the origin image
   * @param newImage the new image after split
   * @param split    the percentage we want to split.
   */
  void blurSplit(String oldImage, String newImage, int split);

  /**
   * Sharpen split.
   *
   * @param oldImage the origin image
   * @param newImage the new image after split
   * @param split    the percentage we want to split.
   */

  void sharpenSplit(String oldImage, String newImage, int split);

  /**
   * sepia split.
   *
   * @param oldImage the origin image
   * @param newImage the new image after split
   * @param split    the percentage we want to split.
   */

  void sepiaSplit(String oldImage, String newImage, int split);

  /**
   * dither split.
   *
   * @param oldImage the origin image
   * @param newImage the new image after split
   * @param split    the percentage we want to split.
   */

  void ditherSplit(String oldImage, String newImage, int split);


  /**
   * greyscale split.
   *
   * @param oldImage the origin image
   * @param newImage the new image after split
   * @param split    the percentage we want to split.
   */

  void greyscaleSplit(String oldImage, String newImage, int split);

  /**
   * level adjust.
   *
   * @param b        value b
   * @param m        value m
   * @param w        value w
   * @param oldImage the origin image
   * @param newImage the new image after split
   */

  void levelAdj(int b, int m, int w, String oldImage, String newImage);

  /**
   * histogram of image.
   *
   * @param oldImage the origin image
   * @param newImage the new image after split
   */

  void histogram(String oldImage, String newImage) throws IOException;


  /**
   * color correct.
   *
   * @param oldImage the origin image
   * @param newImage the new image after split
   */

  void colorCorrect(String oldImage, String newImage);

  /**
   * level adjust split.
   *
   * @param b        value b
   * @param m        value m
   * @param w        value w
   * @param oldImage the origin image
   * @param newImage the new image after split
   * @param split    value split
   */

  void levelAdjSplit(int b, int m, int w, String oldImage, String newImage, int split);


  /**
   * color correct.
   *
   * @param oldImage the origin image
   * @param newImage the new image after split
   * @param split    the percentage we want to split.
   */

  void colorCorrectSplit(String oldImage, String newImage, int split);

  /**
   * Helper to quit program.
   */
  void quit();

  /**
   * Helper to run program.
   */
  void run() throws IOException;

  /**
   * This class is for the get the buffered Image for the GUI.
   *
   * @param oldImage the old image name
   * @return the buffered image of the image.
   */
  BufferedImage getBufferedImage(String oldImage);

  /**
   * This is the get buffered Image for the histogram.
   *
   * @param oldImage the old Image
   * @return the buffered Image of the histogram
   */
  BufferedImage getHistogram(String oldImage);

  /**
   * This method is for split the red component.
   *
   * @param oldImage the old image
   * @param newImage the new image
   * @param split    the percentage of split
   */
  void redComponentSplit(String oldImage, String newImage, int split);

  /**
   * Split the green component.
   *
   * @param oldImage the old image
   * @param newImage the new image
   * @param split    the percentage of split
   */
  void greenComponentSplit(String oldImage, String newImage, int split);

  /**
   * This method is for split the blue component.
   *
   * @param oldImage the old image
   * @param newImage the new image
   * @param split    the percentage of split
   */
  void blueComponentSplit(String oldImage, String newImage, int split);

  /**
   * This method is for split the flip horizonal.
   *
   * @param oldImage the old image
   * @param newImage the new image
   * @param split    the percentage of split
   */
  void flipHorizonalSplit(String oldImage, String newImage, int split);

  /**
   * This method is for split the flip vertical.
   *
   * @param oldImage the old image
   * @param newImage the new image
   * @param split    the percentage of split
   */
  void flipVerticalSplit(String oldImage, String newImage, int split);

  /**
   * This method is for split the compression image.
   *
   * @param oldImage   the old image
   * @param newImage   the new image
   * @param split      the percentage of split
   * @param percentage the percentage of compression
   */
  void compressionSplit(String oldImage, String newImage, int split, int percentage);

  /**
   * This method is for split the luma.
   *
   * @param oldImage the old image
   * @param newImage the new image
   * @param split    the percentage of split
   */
  void lumaSplit(String oldImage, String newImage, int split);
}
