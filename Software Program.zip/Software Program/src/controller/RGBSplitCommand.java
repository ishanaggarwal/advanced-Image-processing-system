package controller;

import java.io.IOException;
import java.util.List;

import view.ConsoleView;

/**
 * A class represents rgb split command  to process image.
 */

public class RGBSplitCommand implements ICommand {
  @Override
  public void execute(Command command, ImageController controller, ConsoleView view)
          throws IOException {
    List<String> args = command.getArguments();
    if (args.size() < 4) {
      view.display(CommandGuide.RGB_SPLIT.getDescription());
      return;
    }
    try {
      controller.rgbSplit(args.get(0), args.get(1), args.get(2), args.get(3));
    } catch (Exception e) {
      view.display("Error processing the image: " + e.getMessage());
    }
  }
}
