package controller;

import java.io.IOException;

import view.ConsoleView;

/**
 * A class represents help command  to process image.
 */

public class HelpCommand implements ICommand {
  @Override
  public void execute(Command command, ImageController controller, ConsoleView view)
          throws IOException {
    view.display(CommandGuide.getHelpDescription());
  }
}
