import modehanlder.ModeHandler;
/**
 * Main class to run program.
 */

public class Main {

  /**
   * main function.
   *
   * @param args : arguments.
   */

  public static void main(String[] args) {
    ModeHandler modelHandler = new ModeHandler();
    modelHandler.startApplication(args);
  }
}

