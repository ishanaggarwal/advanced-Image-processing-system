package imageio;

import java.awt.image.BufferedImage;
import java.io.IOException;

import model.Image;

/**
 * Class to load and save image.
 */

public interface ImageLoaderSaver {

  /**
   * read PPM image.
   *
   * @param filename image name.
   * @return : image.
   */

  Image readPPM(String filename);

  /**
   * read JPG image.
   *
   * @param filename image name.
   * @return : image.
   */

  Image readPNGAndJPG(String filename);

  /**
   * get the image as bufferedImage type.
   * @param image the Image object we have
   * @return buffered image
   */
  BufferedImage getBufferedImage(Image image);

  /**
   * save the image.
   * @param image Image we want to save
   * @param path the path of the saving image
   * @param type the type of the saving image.
   * @throws IOException once the type is illegal, throws the exception.
   */
  void saveImage(Image image, String path, String type) throws IOException;
}
