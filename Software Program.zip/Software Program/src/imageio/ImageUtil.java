package imageio;

import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.imageio.ImageIO;

import model.FilePathHandle;
import model.Image;
import model.Pixel;


/**
 * This class contains utility methods to read a PPM image from file and simply print its contents.
 */
public class ImageUtil implements ImageLoaderSaver {

  /**
   * Image util class.
   */
  public ImageUtil() {
    //this is the constructor of this class.
  }

  /**
   * Read an image file in the PPM format and print the colors.
   *
   * @param filename the path of the file.
   */
  public Image readPPM(String filename) {
    Scanner sc;
    String name = FilePathHandle.getAbsolutePath(filename);
    try {
      sc = new Scanner(new FileInputStream(name));
    } catch (FileNotFoundException e) {
      System.out.println("File " + filename + " not found!");
      return null;
    }
    StringBuilder builder = new StringBuilder();
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (s.charAt(0) != '#') {
        builder.append(s + System.lineSeparator());
      }
    }

    sc = new Scanner(builder.toString());

    String token;

    token = sc.next();
    if (!token.equals("P3")) {
      System.out.println("Invalid PPM file: plain RAW file should begin with P3");
    }
    int width = sc.nextInt();
    System.out.println("Width of image: " + width);
    int height = sc.nextInt();
    System.out.println("Height of image: " + height);
    int maxValue = sc.nextInt();
    System.out.println("Maximum value of a color in this file (usually 255): " + maxValue);
    Image img = new Image(width, height);
    Pixel[][] panel = img.getImage();
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        int r = sc.nextInt();
        int g = sc.nextInt();
        int b = sc.nextInt();
        panel[j][i] = new Pixel(r, g, b);
        System.out.println("Color of pixel (" + j + "," + i + "): " + r + "," + g + "," + b);
      }
    }
    img.setImage(panel);
    return img;
  }

  /**
   * Read PNG image.
   *
   * @param filename image name.
   * @return image
   */

  public Image readPNGAndJPG(String filename) {
    String name = FilePathHandle.getAbsolutePath(filename);
    try {

      BufferedImage image = ImageIO.read(new File(name));

      int width = image.getWidth();
      int height = image.getHeight();
      Image img = new Image(width, height);
      Pixel[][] panel = img.getImage();
      for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
          int rgb = image.getRGB(i, j);

          int red = (rgb >> 16) & 0xFF;

          int green = (rgb >> 8) & 0xFF;

          int blue = rgb & 0xFF;

          panel[i][j].setR(red);

          panel[i][j].setG(green);
          panel[i][j].setB(blue);
        }
      }
      img.setImage(panel);
      return img;
    } catch (IOException e) {
      System.out.println("illegal image");
    }
    return null;

  }

  /**
   * get the buffered image.
   *
   * @param image the Image object we have
   * @return get the buffered image.
   */
  public BufferedImage getBufferedImage(Image image) {
    int width = image.getWidth();
    int height = image.getHeight();
    BufferedImage save = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        int r = image.getImage()[i][j].getR();
        int g = image.getImage()[i][j].getG();
        int b = image.getImage()[i][j].getB();
        int rgb = (r << 16) | (g << 8) | b;
        save.setRGB(i, j, rgb);
      }
    }
    return save;
  }

  @Override
  public void saveImage(Image image, String path, String type) throws IOException {
    BufferedImage save = getBufferedImage(image);
    File outputFile = new File(FilePathHandle.getAbsolutePath(path));
    if (type.equals("ppm")) {
      savePPM(image, FilePathHandle.getAbsolutePath(path));
    } else {
      ImageIO.write(save, type, outputFile);
    }
  }

  private void savePPM(Image image, String path) throws IOException {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {

      writer.write("P3\n# this is command\n");
      writer.write(image.getWidth() + " " + image.getHeight() + "\n255\n");
      Pixel[][] pixels = image.getImage();
      for (int i = 0; i < image.getHeight(); i++) {
        for (int j = 0; j < image.getWidth(); j++) {
          Pixel pixel = pixels[j][i];
          writer.write(pixel.getR() + " " + pixel.getG() + " " + pixel.getB() + " ");
        }
        writer.newLine();
      }
    }
  }
}

