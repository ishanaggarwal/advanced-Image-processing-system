package model;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * A class to handle file path.
 */

public class FilePathHandle {

  /**
   * Gets the absolute path to a file within the project directory.
   *
   * @param filename The name of the file.
   * @return The absolute path to the file.
   */

  public static String getAbsolutePath(String filename) {
    // Get the current working directory (i.e., the project directory)
    Path currentWorkingDirectory = Paths.get("").toAbsolutePath();

    // Construct the path to the ass4 directory within the project directory
    Path ass4Directory = currentWorkingDirectory.resolve("");

    // Construct the path to the file within the ass4 directory
    Path filePath = ass4Directory.resolve(filename);

    return filePath.toString();
  }
}
