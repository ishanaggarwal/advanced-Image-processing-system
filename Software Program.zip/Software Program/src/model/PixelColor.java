package model;

/**
 * Enum class to store rbg.
 */

public enum PixelColor {

  /**
   * Enum class to store rbg.
   */

  RED, GREEN, BLUE

}
