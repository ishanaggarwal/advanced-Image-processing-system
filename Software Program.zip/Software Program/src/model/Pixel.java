package model;

/**
 * A class to represent image pixel.
 */

public class Pixel {
  protected int r;
  protected int g;
  protected int b;

  /**
   * Pixel class.
   */
  public Pixel() {
    //this is the constructor of the Pixel.
  }

  /**
   * Pixel class.
   *
   * @param r red
   * @param g green
   * @param b blue
   * @throws IllegalArgumentException when value of r/g/b out of bound
   */

  public Pixel(int r, int g, int b) throws IllegalArgumentException {
    if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255) {
      throw new IllegalArgumentException("this pixel is not legal.");
    }
    this.r = r;
    this.g = g;
    this.b = b;

  }

  /**
   * Get red.
   *
   * @return red
   */

  public int getR() {
    return r;
  }

  /**
   * set red.
   *
   * @param r red
   */

  public void setR(int r) {
    this.r = r;
  }

  /**
   * Get greed.
   *
   * @return green
   */

  public int getG() {
    return g;
  }

  /**
   * set greed.
   *
   * @param g green
   */

  public void setG(int g) {
    this.g = g;
  }

  /**
   * Get blue.
   *
   * @return blue
   */
  public int getB() {
    return b;
  }

  /**
   * set blue.
   *
   * @param b blue
   */

  public void setB(int b) {
    this.b = b;
  }

}
