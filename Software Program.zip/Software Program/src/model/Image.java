package model;

/**
 * A class to implement and represent image.
 */

public class Image implements ImageInterface {

  private int width;
  private int height;
  private Pixel[][] image;

  /**
   * Image class.
   */

  public Image() {
    //This is the constructor of Image class.
  }

  /**
   * Image width and height.
   */

  public Image(int width, int height) {
    image = new Pixel[width][height];
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        image[i][j] = new Pixel();
      }
    }
    this.width = width;
    this.height = height;
  }


  @Override
  public Pixel[][] getImage() {
    return image;
  }


  @Override
  public void setImage(Pixel[][] image) {
    this.image = image;
  }


  @Override
  public int getWidth() {
    return width;
  }


  @Override
  public void setWidth(int width) {
    this.width = width;
  }


  @Override
  public int getHeight() {
    return height;
  }

  @Override
  public void setHeight(int height) {
    this.height = height;
  }

  @Override
  public int[][] getValue() {
    return caluValue("value");
  }

  @Override
  public int[][] getIntensity() {
    return caluValue("intersity");
  }

  @Override
  public int[][] getLuma() {
    return caluValue("luma");
  }

  /**
   * Helper ro get calculate type value of image.
   *
   * @param func type of greyscale
   * @return 2d array value
   */

  private int[][] caluValue(String func) {
    int[][] value = new int[width][height];
    double[] luma = {0.2126, 0.7152, 0.0722};
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        if (func.equals("value")) {
          value[i][j] = Math.max(image[i][j].r, Math.max(image[i][j].g, image[i][j].b));

        } else if (func.equals("intersity")) {
          value[i][j] = image[i][j].r + image[i][j].g + image[i][j].b;
          value[i][j] = Math.round(value[i][j] / 3);
        } else if (func.equals("luma")) {
          value[i][j] = (int) Math.round(luma[0] * image[i][j].r + luma[1]
                  * image[i][j].g + luma[2] * image[i][j].b);
        }

      }
    }
    return value;
  }

  /**
   * get color of pixel.
   *
   * @param color pixel color
   * @return color array
   */

  public double[][] getColor(PixelColor color) {
    double[][] array = new double[width][height];
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        if (color == PixelColor.RED) {
          array[i][j] = image[i][j].r;
        } else if (color == PixelColor.GREEN) {
          array[i][j] = image[i][j].g;
        } else if (color == PixelColor.BLUE) {
          array[i][j] = image[i][j].b;
        }

      }
    }
    return array;
  }
}
