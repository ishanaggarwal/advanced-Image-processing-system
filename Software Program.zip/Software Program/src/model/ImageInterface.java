package model;

/**
 * Interface of image.
 */

public interface ImageInterface {
  /**
   * get image.
   *
   * @return image 2d array
   */
  Pixel[][] getImage();

  /**
   * Image setter.
   *
   * @param image image 2d array
   */

  void setImage(Pixel[][] image);

  /**
   * get Image width.
   *
   * @return image width
   */

  int getWidth();

  /**
   * Image width setter.
   *
   * @param width image width
   */
  void setWidth(int width);

  /**
   * get Image height.
   *
   * @return iamge height
   */

  int getHeight();

  /**
   * Image height setter.
   *
   * @param height image height
   */

  void setHeight(int height);

  /**
   * get the maximum value of the three components for each pixel.
   *
   * @return a 2D array of integer value which contain the maximum value of
   *         three components for each pixel.
   */
  int[][] getValue();

  /**
   * the average of the three components for each pixel.
   *
   * @return a 2D array of integer value which contains
   *         the average of the three components for each pixel.
   */
  int[][] getIntensity();

  /**
   * the weighted sum 0.2126r + 0.7152g + 0.0722b.
   *
   * @return a 2D array of integer value which weighted sum of each pixel
   */
  int[][] getLuma();

}
