package model;

import imageio.ImageUtil;
import java.io.IOException;
import java.util.Set;
import java.util.TreeSet;

/**
 * Class represent manipulate image and the different operation.
 */

public class ImageManipulator {

  /**
   * This is the load image path.
   *
   * @param file filename
   * @return a image object.
   * @throws IllegalArgumentException if the name is illegal, error processing.
   */
  public Image loadImagePath(String file) throws IllegalArgumentException {
    String filename = file.split("\\.")[0];
    String extension = file.split("\\.")[1];
    Image img = new Image();
    ImageUtil imageUtil = new ImageUtil();
    if (extension.equals("jpg") || extension.equals("png")) {
      img = imageUtil.readPNGAndJPG(file);
    } else if (extension.equals("ppm")) {
      img = imageUtil.readPPM(file);
    } else {
      throw new IllegalArgumentException("illegal file name");
    }

    return img;
  }

  /**
   * class saving image.
   *
   * @param path image path
   * @param type image type
   * @param img  image
   * @throws IOException when error saving
   */


  public void saveImageByPath(String path, String type, Image img) throws IOException {
    ImageUtil imageUtil = new ImageUtil();
    if (!type.equals("jpg") && !type.equals("ppm") && !type.equals("png")) {
      throw new IOException("this illegal type you have");
    }
    imageUtil.saveImage(img, path, type);
  }

  /**
   * for this method, we shall file the image by horizontally. which by change their pixel's x axe
   * to the end.
   *
   * @param image image.
   */

  public Image filpHorizontally(Image image) {
    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] resultPixel = new Pixel[width][height];
    Pixel[][] originPixel = image.getImage();
    Image img = new Image(width, height);
    int count = 0;
    for (int i = width - 1; i >= 0; i--) {
      System.arraycopy(originPixel[i], 0, resultPixel[count], 0, height);
      count++;
    }
    img.setImage(resultPixel);
    return img;
  }

  /**
   * flip vertically.
   */


  public Image filpVertically(Image image) {
    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] resultPixel = new Pixel[width][height];
    Pixel[][] originPixel = image.getImage();
    Image img = new Image(width, height);

    for (int i = 0; i < width; i++) {
      int count = 0;
      for (int j = height - 1; j >= 0; j--) {
        resultPixel[i][count] = originPixel[i][j];
        count++;
      }

    }
    img.setImage(resultPixel);
    return img;
  }

  /**
   * brighten image.
   *
   * @param image image
   * @param num   brighten value
   * @return brightened image
   */


  public Image brighten(Image image, int num) {
    return helperOfLight(image, num, true);
  }

  /**
   * get green component.
   *
   * @param image image
   * @return image
   */

  public Image greenComponent(Image image) {
    return colorComponent(image, "green");
  }


  /**
   * get blue component.
   *
   * @param image image
   * @return image
   */

  public Image blueComponent(Image image) {
    return colorComponent(image, "blue");
  }


  /**
   * get red component.
   *
   * @param image image
   * @return image
   */

  public Image redComponent(Image image) {
    return colorComponent(image, "red");
  }


  /**
   * get color component.
   *
   * @param image image
   * @return image
   */

  private Image colorComponent(Image image, String type) {
    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] pixels = image.getImage();
    Pixel[][] resultPixels = new Pixel[width][height];
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        int r = 0;
        int g = 0;
        int b = 0;
        if (type.equals("red")) {
          r = pixels[i][j].r;
        } else if (type.equals("green")) {
          g = pixels[i][j].g;
        } else if (type.equals("blue")) {
          b = pixels[i][j].b;
        }
        resultPixels[i][j] = new Pixel(r, g, b);
      }
    }
    Image result = new Image(width, height);
    result.setImage(resultPixels);
    return result;
  }

  /**
   * helper function for light.
   */


  private Image helperOfLight(Image image, int num, boolean flag) {
    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] pixels = image.getImage();
    Pixel[][] resultPixels = new Pixel[width][height];
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        int r = 0;
        int g = 0;
        int b = 0;
        if (flag) {
          if (pixels[i][j].r + num <= 255) {
            r = pixels[i][j].r + num;
          } else {
            r = 255;
          }
          if (pixels[i][j].g + num <= 255) {
            g = pixels[i][j].g + num;
          } else {
            g = 255;
          }
          if (pixels[i][j].b + num <= 255) {
            b = pixels[i][j].b + num;
          } else {
            b = 255;
          }
          resultPixels[i][j] = new Pixel(r, g, b);
        } else {
          if (pixels[i][j].r - num >= 0) {
            r = pixels[i][j].r - num;
          } else {
            r = 0;
          }
          if (pixels[i][j].g - num >= 0) {
            g = pixels[i][j].g - num;
          } else {
            g = 0;
          }
          if (pixels[i][j].b - num >= 0) {
            b = pixels[i][j].b - num;
          } else {
            b = 0;
          }
          resultPixels[i][j] = new Pixel(r, g, b);
        }
      }
    }
    Image result = new Image(width, height);
    result.setImage(resultPixels);
    return result;
  }


  /**
   * darken image.
   *
   * @param image image
   * @param num   darken value
   * @return new image
   */


  public Image darken(Image image, int num) {
    return helperOfLight(image, num, false);
  }

  /**
   * split image.
   *
   * @param image image to process
   * @return new image
   */

  public Image[] splitToThreeColorImages(Image image) {
    Image[] images = new Image[3];
    int width = image.getWidth();
    int height = image.getHeight();
    images[0] = redComponent(image);
    images[1] = greenComponent(image);
    images[2] = blueComponent(image);
    return images;

  }

  /**
   * Combined image.
   *
   * @param r : r- component image.
   * @param g : g- component image.
   * @param b : b- component image.
   */

  public Image combineToOneImage(Image r, Image g, Image b) {
    int width = r.getWidth();
    int height = r.getHeight();
    Pixel[][] pixelsR = r.getImage();
    Pixel[][] pixelsG = g.getImage();
    Pixel[][] pixelsB = b.getImage();

    Pixel[][] resultPixels = new Pixel[width][height];
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        int rV = 0;
        int gV = 0;
        int bV = 0;
        rV = pixelsR[i][j].r;
        gV = pixelsG[i][j].g;
        bV = pixelsB[i][j].b;
        resultPixels[i][j] = new Pixel(rV, gV, bV);
      }
    }
    Image img = new Image(width, height);
    img.setImage(resultPixels);
    return img;
  }

  /**
   * GreyScale, depending on component.
   *
   * @param image : image.
   */

  public Image valueComponent(Image image) {
    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] resultPixels = new Pixel[width][height];
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        int r = 0;
        int g = 0;
        int b = 0;
        int value = image.getValue()[i][j];
        r = value;
        g = value;
        b = value;
        resultPixels[i][j] = new Pixel(r, g, b);
      }
    }
    Image img = new Image(width, height);
    img.setImage(resultPixels);
    return img;

  }

  /**
   * Intensity greyscale.
   *
   * @param image image to process
   * @return new image
   */

  public Image intensityComponent(Image image) {
    int width = image.getWidth();
    int height = image.getHeight();
    int count = 0;
    Pixel[][] resultPixels = new Pixel[width][height];
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        int r = 0;
        int g = 0;
        int b = 0;
        int value = image.getIntensity()[i][j];
        r = value;
        g = value;
        b = value;
        resultPixels[i][j] = new Pixel(r, g, b);
      }
    }
    Image img = new Image(width, height);
    img.setImage(resultPixels);
    return img;

  }

  /**
   * Luma greyscale.
   *
   * @param image image to process
   * @return new image
   */


  public Image lumaComponent(Image image) {
    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] resultPixels = new Pixel[width][height];
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        int r = 0;
        int g = 0;
        int b = 0;
        int value = image.getLuma()[i][j];
        r = value;
        g = value;
        b = value;
        resultPixels[i][j] = new Pixel(r, g, b);
      }
    }
    Image img = new Image(width, height);
    img.setImage(resultPixels);
    return img;

  }

  /**
   * Blur image.
   *
   * @param image image to process
   * @return new image
   */

  public Image blur(Image image) {
    double[][] array = {
        {1.0 / 16.0, 1.0 / 8, 1.0 / 16},
        {1.0 / 8, 1.0 / 4, 1.0 / 8},
        {1.0 / 16, 1.0 / 8, 1.0 / 16}
    };
    return filtering(array, image);
  }

  /**
   * sharpen image.
   *
   * @param image image.
   */

  public Image sharpen(Image image) {
    double[][] array = {
        {-1.0 / 8, -1.0 / 8, -1.0 / 8, -1.0 / 8, -1.0 / 8},
        {-1.0 / 8, 1.0 / 4, 1.0 / 4, 1.0 / 4, -1.0 / 8},
        {-1.0 / 8, 1.0 / 4, 1.0, 1.0 / 4, -1.0 / 8},
        {-1.0 / 8, 1.0 / 4, 1.0 / 4, 1.0 / 4, -1.0 / 8},
        {-1.0 / 8, -1.0 / 8, -1.0 / 8, -1.0 / 8, -1.0 / 8}
    };
    return filtering(array, image);
  }

  /**
   * Filter image.
   *
   * @param image image.
   */

  private Image filtering(double[][] kernel, Image image) {
    int center = kernel.length / 2;
    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] pixels = image.getImage();
    Pixel[][] resultPixels = new Pixel[width][height];
    int[][] red = new int[width][height];
    int[][] green = new int[width][height];
    int[][] blue = new int[width][height];
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        red[i][j] = pixels[i][j].r;
        green[i][j] = pixels[i][j].g;
        blue[i][j] = pixels[i][j].b;
      }
    }
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        int r = 0;
        int g = 0;
        int b = 0;
        int x = 0;
        int y = 0;
        int xRange = kernel.length;
        int yRange = kernel.length;
        if (i < center) {
          x = center - i;

        } else if (i + center >= width) {
          xRange = width - i;
        }
        if (j < center) {
          y = center - j;

        } else if (j + center >= height) {
          yRange = height - j;
        }
        int x1 = x;
        while (x1 < xRange) {
          int y1 = y;
          while (y1 < yRange) {
            r += red[i - center + x1][j - center + y1] * kernel[x1][y1];
            g += green[i - center + x1][j - center + y1] * kernel[x1][y1];
            b += blue[i - center + x1][j - center + y1] * kernel[x1][y1];
            y1++;
          }

          x1++;
        }
        if (r > 255) {
          r = 255;
        }
        if (g > 255) {
          g = 255;
        }
        if (b > 255) {
          b = 255;
        }
        if (r < 0) {
          r = 0;
        }
        if (g < 0) {
          g = 0;
        }
        if (b < 0) {
          b = 0;
        }

        resultPixels[i][j] = new Pixel(Math.round(r),
            Math.round(g), Math.round(b));
      }
    }
    Image img = new Image(width, height);
    img.setImage(resultPixels);
    return img;
  }

  /**
   * Sepia conversation.
   *
   * @param image image.
   * @return new image.
   */

  public Image convertSepia(Image image) {
    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] pixels = image.getImage();
    Pixel[][] resultPixels = new Pixel[width][height];
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        int r = 0;
        int g = 0;
        int b = 0;
        int rV = pixels[i][j].r;
        int gV = pixels[i][j].g;
        int bV = pixels[i][j].b;

        r = (int) Math.round(0.393 * rV + 0.769 * gV + 0.189 * bV);
        g = (int) Math.round(0.349 * rV + 0.686 * gV + 0.168 * bV);
        b = (int) Math.round(0.272 * rV + 0.534 * gV + 0.131 * bV);
        if (r > 255) {
          r = 255;
        }
        if (g > 255) {
          g = 255;
        }
        if (b > 255) {
          b = 255;
        }
        resultPixels[i][j] = new Pixel(r, g, b);
      }
    }
    Image img = new Image(width, height);
    img.setImage(resultPixels);
    return img;
  }

  /**
   * Dither conversation.
   *
   * @param image image.
   * @return new image.
   */

  public Image dither(Image image) {
    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] u = image.getImage();
    Pixel[][] v = new Pixel[width][height];

    // intensity greyscale
    for (int i = 0; i < height; ++i) {
      for (int j = 0; j < width; ++j) {
        var p = u[j][i];
        var m = (int) Math.round((p.r + p.g + p.b) / 3.);
        v[j][i] = new Pixel(m, m, m);
      }
    }

    // dither
    for (int i = 0; i < height; ++i) {
      for (int j = 0; j < width; ++j) {
        var p = v[j][i];
        var oldColor = p.r;
        // tried both. 128 closer to 0 and 255.
        var newColor = (oldColor < 128) ? 0 : 255;
        p.r = newColor;
        p.g = newColor;
        p.b = newColor;
        var error = oldColor - newColor;

        var iter = new double[][]{
            {0, 1, 7. / 16.},
            {1, -1, 3. / 16.},
            {1, 0, 5. / 16.},
            {1, 1, 1. / 16.}
        };
        for (var x : iter) {
          var r = i + (int) x[0];
          var c = j + (int) x[1];
          var add = (int) Math.round(x[2] * error);

          if (r < 0 || r >= height || c < 0 || c >= width) {
            continue;
          }

          var other = v[c][r];
          // updating only r as that's what I use for the operation
          other.r += add;
        }
      }
    }

    for (int i = 0; i < height; ++i) {
      for (int j = 0; j < width; ++j) {
        v[j][i].r = Math.max(0, Math.min(255, v[j][i].r));
        v[j][i].g = Math.max(0, Math.min(255, v[j][i].g));
        v[j][i].b = Math.max(0, Math.min(255, v[j][i].b));
      }
    }


    Image img = new Image(width, height);
    img.setImage(v);
    return img;
  }


  /**
   * This method is for get the limit value based on the percentage of compression.
   *
   * @param red        red component
   * @param green      green component
   * @param blue       blie component
   * @param percentage the percent we want to convert.
   * @return the value of the limit
   */
  private double getPercentage(double[][] red, double[][] green, double[][] blue, int percentage) {
    Set<Double> sortedSet = new TreeSet<>();
    for (int i = 0; i < red.length; i++) {
      for (int j = 0; j < red.length; j++) {
        if (Math.round(Math.abs(red[i][j])) != 0) {
          sortedSet.add(Math.abs(red[i][j]));
        }

        if (Math.round(Math.abs(green[i][j])) != 0) {
          sortedSet.add(Math.abs(green[i][j]));
        }

        if (Math.round(Math.abs(blue[i][j])) != 0) {
          sortedSet.add(Math.abs(blue[i][j]));
        }
      }
    }

    double percent = (double) percentage / 100;
    int valueIndex = (int) ((sortedSet.size() - 1) * percent);
    int count = 0;
    double result = 0;
    for (Double i : sortedSet) {
      if (count == valueIndex) {
        result = i;
        break;
      }
      count++;
    }
    return result;
  }

  /**
   * Split image.
   *
   * @param image      image to process
   * @param percentage split value
   * @param str        type of split
   * @return new image
   */

  public Image imageSplit(Image image, int percentage, String str)
      throws IllegalArgumentException {
    if (percentage < 0 || percentage > 100) {
      throw new IllegalArgumentException("the percentage is not in the right range, the right ran");
    }
    int width = image.getWidth();
    int height = image.getHeight();
    int leftWidth = getLeftWidthForSplit(width, percentage) + 10;
    int rightWidth = width - leftWidth + 10;
    Image left = new Image(width, height);
    Image right = new Image(rightWidth, height);
    split(image, left, right);
    if (str.equals("blur")) {
      left = blur(left);
    } else if (str.equals("sharpen")) {
      left = sharpen(left);
    } else if (str.equals("sepia")) {
      left = convertSepia(left);
    } else if (str.equals("dither")) {
      left = dither(left);
    } else if (str.equals("grey")) {
      left = lumaComponent(left);
    } else if (str.equals("red")) {
      left = redComponent(left);
    } else if (str.equals("blue")) {
      left = blueComponent(left);
    } else if (str.equals("green")) {
      left = greenComponent(left);
    } else if (str.equals("flip Horizonal")) {
      left = filpHorizontally(left);
    } else if (str.equals("flip Vertical")) {
      left = filpVertically(left);
    } else if (str.equals("correction")) {
      left = correction(left);
    } else if (str.equals("luma")) {
      left = lumaComponent(left);
    }
    Image result = new Image(width, height);
    result = imageCombine(left, right);
    return result;
  }

  /**
   * Level adjustment split class.
   *
   * @param image      image
   * @param percentage percentage
   * @param str        flad string
   * @param b          b value
   * @param m          m value
   * @param w          w value
   * @return the image after split
   */
  public Image levelAdjustmentSplit(Image image, int percentage, String str, int b, int m, int w)
      throws IllegalArgumentException {
    if (percentage < 0 || percentage > 100) {
      throw new IllegalArgumentException("the percentage is not in the right range, the right ran");
    }
    int width = image.getWidth();
    int height = image.getHeight();
    int leftWidth = getLeftWidthForSplit(width, percentage) + 10;
    int rightWidth = width - leftWidth + 10;
    Image left = new Image(width, height);
    Image right = new Image(rightWidth, height);
    split(image, left, right);
    if (str.equals("adjustment")) {
      left = levelAdjustment(left, b, m, w);
    }
    Image result = new Image(width, height);
    result = imageCombine(left, right);
    return result;
  }

  /**
   * Compression split method.
   *
   * @param image      the old image
   * @param splitper   the percentage for split
   * @param str        the type of modify
   * @param percentage the percentage of modify
   * @return a new Image
   */
  public Image compressionSplit(Image image, int splitper, String str, int percentage)
      throws IllegalArgumentException {
    if (percentage < 0 || percentage > 100) {
      throw new IllegalArgumentException("the percentage is not in the right range, the right ran");
    }
    int width = image.getWidth();
    int height = image.getHeight();
    int leftWidth = getLeftWidthForSplit(width, splitper) + 10;
    int rightWidth = width - leftWidth + 10;
    Image left = new Image(width, height);
    Image right = new Image(rightWidth, height);
    split(image, left, right);
    if (str.equals("compression")) {
      left = compression(percentage, left);
    }
    Image result = new Image(width, height);
    result = imageCombine(left, right);
    return result;
  }

  /**
   * Split image help method.
   *
   * @param image the origin image value.
   * @param left  the left part of split image
   * @param right the right part of split image
   */
  private void split(Image image, Image left, Image right) {

    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] leftPixel = new Pixel[width][height];
    Pixel[][] rightPixel = new Pixel[right.getWidth()][height];
    Pixel[][] pixels = image.getImage();
    for (int i = 0; i < left.getWidth(); i++) {
      System.arraycopy(pixels[i], 0, leftPixel[i], 0, height);
    }
    for (int i = 0; i < right.getWidth(); i++) {
      System.arraycopy(pixels[i + (width - right.getWidth())], 0, rightPixel[i], 0, height);
    }
    left.setImage(leftPixel);
    right.setImage(rightPixel);
  }

  /**
   * This is the method is help us to compression.
   *
   * @param percentage the percentage to convert.
   * @param image      the image we want to compression
   * @return the image after compression
   */
  public Image compression(int percentage, Image image) throws IllegalArgumentException {
    if (percentage < 0 || percentage > 100) {
      throw new IllegalArgumentException("the percentage of compression shall be in range(0,100)");
    }
    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] result = new Pixel[image.getWidth()][image.getHeight()];
    double[][] red = redComponent(image).getColor(PixelColor.RED);
    double[][] green = greenComponent(image).getColor(PixelColor.GREEN);
    double[][] blue = blueComponent(image).getColor(PixelColor.BLUE);
    red = compressionCal(red);
    green = compressionCal(green);
    blue = compressionCal(blue);
    double limit = getPercentage(red, green, blue, percentage);
    red = reverseCal(red, width, height, limit);
    green = reverseCal(green, width, height, limit);
    blue = reverseCal(blue, width, height, limit);
    for (int i = 0; i < image.getWidth(); i++) {
      for (int j = 0; j < image.getHeight(); j++) {
        int r = (int) red[i][j];
        if (r < 0) {
          r = 0;
        }
        int g = (int) green[i][j];
        if (g < 0) {
          g = 0;
        }
        int b = (int) blue[i][j];
        if (b < 0) {
          b = 0;
        }
        if (r > 255) {
          r = 255;
        }
        if (g > 255) {
          g = 255;
        }
        if (b > 255) {
          b = 255;
        }
        result[i][j] = new Pixel(r, g, b);
      }

    }
    Image img = new Image(width, height);
    img.setImage(result);
    return img;

  }

  /**
   * This id the calcution for compression the image.
   *
   * @param imageValue the pixel array
   * @return the pixel array after compress
   */
  private double[][] compressionCal(double[][] imageValue) {
    int width = imageValue.length;
    int height = imageValue[0].length;
    int value = Math.max(width, height);
    int sizeOfComp = 0;
    for (int i = 2; i < value; i *= 2) {
      sizeOfComp = i;
    }
    sizeOfComp *= 2;
    double[][] arrayOfComp = new double[sizeOfComp][sizeOfComp];
    for (int i = 0; i < width; i++) {
      System.arraycopy(imageValue[i], 0, arrayOfComp[i], 0, height);
    }
    arrayOfComp = haar(arrayOfComp, sizeOfComp);
    return arrayOfComp;
  }

  /**
   * This reverse image from compress.
   *
   * @param arrayOfComp the pixel array of compress
   * @param width       the width of image
   * @param height      the height of image
   * @param limit       the percentage of lose
   * @return the Pixel array after reverse
   */
  private double[][] reverseCal(double[][] arrayOfComp, int width, int height, double limit) {
    for (int i = 0; i < arrayOfComp.length; i++) {
      for (int j = 0; j < arrayOfComp[0].length; j++) {
        if (limit >= Math.abs(arrayOfComp[i][j])) {
          arrayOfComp[i][j] = 0;
        }
      }
    }
    arrayOfComp = invhaar(arrayOfComp, arrayOfComp.length);
    for (int i = 0; i < arrayOfComp.length; i++) {
      for (int j = 0; j < arrayOfComp[0].length; j++) {
        if (arrayOfComp[i][j] < 0) {
          arrayOfComp[i][j] = 0;
        }
        arrayOfComp[i][j] = Math.round(arrayOfComp[i][j]);
      }
    }
    double[][] result = new double[width][height];
    for (int i = 0; i < width; i++) {
      System.arraycopy(arrayOfComp[i], 0, result[i], 0, height);
    }
    return result;
  }

  /**
   * this is the helper method for haar method.
   *
   * @param array  the compression
   * @param length the length of the array we need compression
   * @return the double array after compression
   */
  private double[][] haar(double[][] array, int length) {
    int count = length;
    while (count > 1) {
      for (int i = 0; i < count; i++) {
        array[i] = transform(array[i], count);
      }
      for (int j = 0; j < count; j++) {
        double[] col = new double[count];
        for (int i = 0; i < count; i++) {
          col[i] = array[i][j];
        }
        col = transform(col, count);
        for (int i = 0; i < count; i++) {
          array[i][j] = col[i];
        }
      }
      count /= 2;
    }
    return array;
  }

  /**
   * Helper to invert harr.
   *
   * @param array  harr array
   * @param length length
   * @return new haar array
   */

  private double[][] invhaar(double[][] array, int length) {
    int count = 2;
    while (count <= length) {
      for (int j = 0; j < count; j++) {
        double[] col = new double[count];
        for (int i = 0; i < count; i++) {
          col[i] = array[i][j];
        }
        col = inverse(col, count);
        for (int i = 0; i < count; i++) {
          array[i][j] = col[i];
        }
      }
      for (int i = 0; i < count; i++) {
        array[i] = inverse(array[i], count);
      }
      count *= 2;
    }
    return array;
  }

  /**
   * transform method.
   *
   * @param array double array need transform
   * @param len   length of part array we need transform
   * @return the array after transform
   */
  public double[] transform(double[] array, int len) {
    int length = len / 2;
    int count = 0;
    double[] result = new double[array.length];
    System.arraycopy(array, 0, result, 0, array.length);
    for (int i = 0; i < len; i += 2) {
      double av = (array[i] + array[i + 1]) / Math.sqrt(2);
      double dv = (array[i] - array[i + 1]) / Math.sqrt(2);
      result[count] = av;
      result[count + length] = dv;
      count++;
    }
    return result;
  }

  /**
   * Inverse image.
   *
   * @param array image array
   * @param len   image array length
   * @return new inverse array
   */

  public double[] inverse(double[] array, int len) {
    int length = len / 2;
    double[] result = new double[array.length];
    System.arraycopy(array, 0, result, 0, array.length);
    int count = 0;
    for (int i = 0; i < length; i++) {
      double av = (array[i] + array[i + length]) / Math.sqrt(2);
      double dv = (array[i] - array[i + length]) / Math.sqrt(2);
      result[count] = av;
      result[count + 1] = dv;
      count += 2;
    }
    return result;
  }

  /**
   * image combine.
   *
   * @param left  left side image
   * @param right right side image
   * @return new image
   * @throws IllegalStateException when height of images the same
   */

  private Image imageCombine(Image left, Image right) throws IllegalStateException {
    if (left.getHeight() != right.getHeight()) {
      throw new IllegalStateException("the height of two image shall be same");
    }
    int leftWidth = left.getWidth() - right.getWidth();
    int rightWidth = right.getWidth();
    int height = left.getHeight();
    Pixel[][] leftP = left.getImage();
    Pixel[][] rightP = right.getImage();
    Image result = new Image(leftWidth + rightWidth, height);
    Pixel[][] combine = new Pixel[leftWidth + rightWidth][height];
    for (int i = 0; i < leftWidth + rightWidth; i++) {
      for (int j = 0; j < height; j++) {
        if (i < leftWidth) {
          combine[i][j] = leftP[i][j];
        } else {
          combine[i][j] = rightP[i - leftWidth][j];
        }
      }
    }
    result.setImage(combine);
    return result;
  }

  /**
   * get left width split.
   *
   * @param width   image width
   * @param percent split value
   * @return new image
   */

  private int getLeftWidthForSplit(int width, int percent) {
    return width * percent / 100;
  }


  /**
   * Level adjust image.
   *
   * @param image image to process
   * @param b     b value
   * @param m     m value
   * @param w     w value
   * @return new image
   */

  public Image levelAdjustment(Image image, int b, int m, int w) throws IllegalArgumentException {
    if (b > m || m > w || b > w) {
      throw new IllegalArgumentException("the b shall be smallest and the w shall be biggest ");
    }
    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] pixels = image.getImage();
    Pixel[][] result = new Pixel[width][height];
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        int r = pixels[i][j].r;
        int g = pixels[i][j].g;
        int b1 = pixels[i][j].b;
        r = valueCal(b, m, w, r);
        g = valueCal(b, m, w, g);
        b1 = valueCal(b, m, w, b1);
        if (r < 0) {
          r = 0;
        }

        if (g < 0) {
          g = 0;
        }
        if (b1 < 0) {
          b1 = 0;
        }
        if (r > 255) {
          r = 255;
        }
        if (g > 255) {
          g = 255;
        }
        if (b1 > 255) {
          b1 = 255;
        }
        result[i][j] = new Pixel(r, g, b1);
      }
    }
    Image resultImage = new Image(width, height);
    resultImage.setImage(result);
    return resultImage;

  }

  /**
   * Helper to Value calculator.
   *
   * @param b value b
   * @param m value m
   * @param w value w
   * @param v value v
   * @return value to calculate
   */


  private int valueCal(int b, int m, int w, int v) {
    int f1 = (b * b) * (m - w) - b * (m * m - w * w) + w * m * m - m * w * w;
    int fa = -b * (128 - 255) + 128 * w - 255 * m;
    int fb = b * b * (128 - 255) + 255 * m * m - 128 * w * w;
    int fc = b * b * (255 * m - 128 * w) - b * (255 * m * m - 128 * w * w);
    double av = fa / f1;
    double bv = fb / f1;
    double cv = fc / f1;
    return (int) (av * v * v + bv * v + cv);
  }

  /**
   * Image data.
   *
   * @param image image to process
   * @return new image
   */

  public int[][] generateData(Image image) {
    int[][] data = new int[3][256];
    Pixel[][] pixels = image.getImage();
    for (int i = 0; i < image.getWidth(); i++) {
      for (int j = 0; j < image.getHeight(); j++) {
        int r = pixels[i][j].getR();
        int g = pixels[i][j].getG();
        int b = pixels[i][j].getB();
        data[0][r]++;
        data[1][g]++;
        data[2][b]++;

      }
    }
    return data;
  }

  /**
   * Color correction.
   *
   * @param image image
   * @return new image after color correction
   */
  public Image correction(Image image) {
    int[][] data = generateData(image);
    int maxR = 0;
    int maxG = 0;
    int maxB = 0;
    int countR = 0;
    int countG = 0;
    int countB = 0;
    for (int i = 10; i < 245; i++) {
      if (data[0][i] > countR) {
        countR = data[0][i];
        maxR = i;
      }
      if (data[1][i] > countG) {
        countG = data[1][i];
        maxG = i;
      }
      if (data[2][i] > countB) {
        countB = data[2][i];
        maxB = i;
      }
    }
    int avg = (maxR + maxB + maxG) / 3;
    int rChange = maxR - avg;
    int gChange = maxG - avg;
    int bChange = maxB - avg;
    int width = image.getWidth();
    int height = image.getHeight();
    Pixel[][] pixels = image.getImage();
    Pixel[][] result = new Pixel[width][height];
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        Pixel pixel = pixels[i][j];
        int r = pixel.r;
        int g = pixel.g;
        int b = pixel.b;
        if (pixel.r >= 10 || pixel.r < 245) {
          r -= rChange;
        }
        if (pixel.g >= 10 || pixel.g < 245) {
          g -= gChange;
        }
        if (pixel.b >= 10 || pixel.b < 245) {
          b -= bChange;
        }
        if (r < 0) {
          r = 0;
        }

        if (g < 0) {
          g = 0;
        }
        if (b < 0) {
          b = 0;
        }
        if (r > 255) {
          r = 255;
        }
        if (g > 255) {
          g = 255;
        }
        if (b > 255) {
          b = 255;
        }
        result[i][j] = new Pixel(r, g, b);
      }
    }
    Image img = new Image(width, height);
    img.setImage(result);
    return img;
  }
}
