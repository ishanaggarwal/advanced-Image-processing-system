package modehanlder;

import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.UIManager;

import controller.ImageController;
import model.ImageManipulator;
import view.ConsoleView;
import view.SwingFeaturesFrame;

/**
 * A class handle which mode to use.
 */

public class ModeHandler {

  /**
   * Mode to use when started.
   */

  private boolean isGuiInitialized = false;
  private boolean isCommandLineInitialized = false;
  private boolean isScriptModeInitialized = false;
  private boolean isInvalidArgumentsHandled = false;

  private ImageController controller;

  /**
   * A class handle which mode to start.
   * @param args arguments
   */

  public void startApplication(String[] args) {
    ImageManipulator model = new ImageManipulator();
    ConsoleView consoleView = new ConsoleView(new InputStreamReader(System.in), System.out);
    SwingFeaturesFrame guiView = new SwingFeaturesFrame(controller);

    try {
      if (args.length == 0) {
        initializeGuiMode(model, guiView);
      } else if (args.length == 1 && "-text".equals(args[0])) {
        initializeCommandLineMode(model, consoleView);
      } else if (args.length == 2 && "-file".equals(args[0])) {
        initializeScriptMode(model, consoleView, args[1]);
      } else {
        handleInvalidArguments();
      }
    } catch (Exception e) {
      // Log or handle the exception as needed
      System.err.println("Error: " + e.getMessage());
      throw new IllegalArgumentException("Invalid command-line arguments.");

    }
  }

  /**
   * Helper class handle when each mode start.
   */

  private void initializeGuiMode(ImageManipulator model, SwingFeaturesFrame guiView) {
    controller = new ImageController(model);
    guiView.setVisible(true);
    isGuiInitialized = true;
    setLookAndFeel();
  }

  /**
   * Helper class handle when each mode start.
   */

  private void initializeCommandLineMode(ImageManipulator model, ConsoleView consoleView) {
    controller = new ImageController(model, consoleView);
    isCommandLineInitialized = true;
    try {
      controller.run();
    } catch (IOException e) {
      System.err.println("Error running application: " + e.getMessage());
      isCommandLineInitialized = false;
    }
  }

  /**
   * Helper class handle when each mode start.
   */

  private void initializeScriptMode(ImageManipulator model,
                                    ConsoleView consoleView,
                                    String scriptPath) {
    controller = new ImageController(model, consoleView);
    isScriptModeInitialized = true;
    try {
      controller.runScript(scriptPath);
    } catch (IOException e) {
      System.err.println("Error running script: " + e.getMessage());
      isScriptModeInitialized = false;
    }
  }

  /**
   * Helper class handle when each mode start with GUI.
   */

  private void setLookAndFeel() {
    try {
      UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
    } catch (Exception e) {
      System.err.println("Error setting Look and Feel: " + e.getMessage());
    }
  }

  /**
   * Helper class handle when error in mode start.
   */


  private void handleInvalidArguments() {
    isInvalidArgumentsHandled = true;
    throw new IllegalArgumentException("Invalid command-line arguments.");
  }



  /**
   * Helper checks if the GUI has been initialized.
   * @return true if GUI is initialized, false otherwise.
   */
  public boolean isGuiInitialized() {
    return isGuiInitialized;
  }

  /**
   * Helper checks if the Command mode has been initialized.
   * @return true if command is initialized, false otherwise.
   */

  public boolean isCommandLineInitialized() {
    return isCommandLineInitialized;
  }

  /**
   * Helper checks if the running script mode has been initialized.
   * @return true if script is initialized, false otherwise.
   */

  public boolean isScriptModeInitialized() {
    return isScriptModeInitialized;
  }

  /**
   * Helper checks if the error opening any mode.
   * @return true if error mode is initialized, false otherwise.
   */

  public boolean isInvalidArgumentsHandled() {
    return isInvalidArgumentsHandled;
  }

}