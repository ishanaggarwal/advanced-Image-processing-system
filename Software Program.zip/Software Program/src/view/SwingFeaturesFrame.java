package view;


import controller.ImageController;
import controller.ImageControllerInterface;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import model.ImageManipulator;


/**
 * This class opens the main window, that has different elements illustrated in it. It also doubles
 * up as all the listeners for simplicity. Such a design is not recommended in general.
 */

public class SwingFeaturesFrame extends JFrame implements ActionListener,
    ItemListener,
    ListSelectionListener {

  private final JLabel itemStateLabel;

  private final JLabel splitDisplay;
  private final JLabel fileOpenDisplay;
  private final JLabel fileSaveDisplay;

  private final JLabel optionDisplay;
  private final JLabel[] imageLabel = new JLabel[2];
  private ImageManipulator model = new ImageManipulator();
  private final ImageControllerInterface controller = new ImageController(model);
  private JList<String> listOfStrings;
  private JList<Integer> listOfIntegers;
  private Boolean flag = false;
  private JPanel imagePanel;
  private int splitValue;
  private int b = 0;
  private int m = 0;
  private int w = 0;
  private int percent = 0;
  private String currentOption = "";

  /**
   * this is the constructor of this plane.
   *
   * @param controller the controller of this project
   */
  public SwingFeaturesFrame(ImageController controller) {
    super();
    itemStateLabel = new JLabel("Initial Text");
    splitValue = 100;
    setTitle("Swing features");
    setSize(400, 400);
    model = new ImageManipulator();
    //SwingFeaturesFrame implements a View interface
    controller = new ImageController(model);

    JPanel mainPanel = new JPanel();
    //for elements to be arranged vertically within this panel
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
    //scroll bars around this main panel
    JScrollPane mainScrollPane = new JScrollPane(mainPanel);
    add(mainScrollPane);

    //show an image with a scrollbar
    JPanel imagePanel = new JPanel();
    //a border around the panel with a caption
    imagePanel.setBorder(BorderFactory.createTitledBorder("Image and it's histogram"));
    imagePanel.setLayout(new GridLayout(1, 0, 10, 10));
    //imagePanel.setMaximumSize(null);
    mainPanel.add(imagePanel);
    JScrollPane[] imageScrollPane = new JScrollPane[2];

    for (int i = 0; i < imageLabel.length; i++) {
      imageLabel[i] = new JLabel();
      imageScrollPane[i] = new JScrollPane(imageLabel[i]);
      imageScrollPane[i].setPreferredSize(new Dimension(100, 600));
      imagePanel.add(imageScrollPane[i]);
    }
    //dialog boxes
    JPanel dialogBoxesPanel = new JPanel();
    dialogBoxesPanel.setBorder(BorderFactory.createTitledBorder("control boxes"));
    dialogBoxesPanel.setLayout(new BoxLayout(dialogBoxesPanel, BoxLayout.PAGE_AXIS));
    mainPanel.add(dialogBoxesPanel);
    //get the split value
    JPanel textPanel = new JPanel();
    textPanel.setLayout(new FlowLayout());
    JTextField text = new JTextField(5);
    JButton updateValue = new JButton("update value");
    splitDisplay = new JLabel("Split percentage: ");

    updateValue.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        try {
          int count = Integer.parseInt(text.getText());
          if (count < 0 || count > 100) {
            JOptionPane.showMessageDialog(SwingFeaturesFrame.this,
                "the value shall be >= 0 and <= 100", "Source",
                JOptionPane.PLAIN_MESSAGE);
          } else {

            splitValue = count;
            splitDisplay.setText("Split value: " + splitValue);
            flag = true;
            modifyMethod();
          }
        } catch (NumberFormatException ex) {
          splitDisplay.setText("Invalid Input!");
        }
      }
    });
    textPanel.add(text);
    textPanel.add(updateValue);
    textPanel.add(splitDisplay);
    dialogBoxesPanel.add(textPanel);
    //file open
    JPanel fileopenPanel = new JPanel();
    fileopenPanel.setLayout(new FlowLayout());
    dialogBoxesPanel.add(fileopenPanel);
    JButton fileOpenButton = new JButton("Open a file");
    fileOpenButton.setActionCommand("Open file");
    fileOpenButton.addActionListener(this);
    fileopenPanel.add(fileOpenButton);
    fileOpenDisplay = new JLabel("File path will appear here");
    fileopenPanel.add(fileOpenDisplay);

    //file save
    JPanel filesavePanel = new JPanel();
    filesavePanel.setLayout(new FlowLayout());
    dialogBoxesPanel.add(filesavePanel);
    JButton fileSaveButton = new JButton("Save a file");
    fileSaveButton.setActionCommand("Save file");
    fileSaveButton.addActionListener(this);
    filesavePanel.add(fileSaveButton);
    fileSaveDisplay = new JLabel("File path will appear here");
    filesavePanel.add(fileSaveDisplay);
    //JOptionsPane options dialog
    JPanel optionsDialogPanel = new JPanel();
    optionsDialogPanel.setLayout(new FlowLayout());
    dialogBoxesPanel.add(optionsDialogPanel);

    JButton optionButton = new JButton("the modify option");
    optionButton.setActionCommand("Option");
    optionButton.addActionListener(this);
    optionsDialogPanel.add(optionButton);

    optionDisplay = new JLabel("Default");
    optionsDialogPanel.add(optionDisplay);


  }


  @Override
  public void actionPerformed(ActionEvent arguments) {
    // TODO Auto-generated method stub
    switch (arguments.getActionCommand()) {
      case "Open file": {
        final JFileChooser fchooser = new JFileChooser(".");
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "JPG & GIF Images", "jpg", "png", "ppm");
        fchooser.setFileFilter(filter);
        int retvalue = fchooser.showOpenDialog(SwingFeaturesFrame.this);
        if (retvalue == JFileChooser.APPROVE_OPTION) {
          File f = fchooser.getSelectedFile();
          controller.load(f.getAbsolutePath(), "saveImg");
          controller.load(f.getAbsolutePath(), "saveImg1");
          fileOpenDisplay.setText(f.getAbsolutePath());
          updateImage();
        }
        break;
      }

      case "Save file": {
        final JFileChooser fchooser = new JFileChooser(".");
        int retvalue = fchooser.showSaveDialog(SwingFeaturesFrame.this);
        if (retvalue == JFileChooser.APPROVE_OPTION) {
          File f = fchooser.getSelectedFile();
          try {
            controller.save(f.getAbsolutePath(), "saveImg1");
          } catch (IOException e) {
            throw new RuntimeException(e);
          }
          fileSaveDisplay.setText(f.getAbsolutePath());
        }
      }
      break;
      case "Option": {
        String[] options = {
            "getRed",
            "getGreen",
            "getBlue",
            "flipHorizontal",
            "flipVertical",
            "blur",
            "sharpen",
            "luma",
            "sepia",
            "dither",
            "compression",
            "adjustLevel",
            "color-correct"
        };
        flag = false;
        int retvalue = JOptionPane.showOptionDialog(SwingFeaturesFrame.this,
            "Please choose the way you want to modify", "Modify Method",
            JOptionPane.YES_OPTION,
            JOptionPane.INFORMATION_MESSAGE, null, options, options[4]);
        currentOption = options[retvalue];
        optionDisplay.setText(options[retvalue]);
        modifyMethod();
      }
      break;

      default:
        break;

    }
  }

  /**
   * This method is help the class to modify the image.
   */
  private void modifyMethod() {
    switch (currentOption) {
      case "getRed":
        controller.redComponentSplit("saveImg", "saveImg1", splitValue);
        updateImage();
        break;
      case "getBlue":
        controller.blueComponentSplit("saveImg", "saveImg1", splitValue);
        updateImage();
        break;
      case "getGreen":
        controller.greenComponentSplit("saveImg", "saveImg1", splitValue);
        updateImage();
        break;
      case "flipHorizontal":
        controller.flipHorizonalSplit("saveImg", "saveImg1", splitValue);
        updateImage();
        break;
      case "flipVertical":
        controller.flipVerticalSplit("saveImg", "saveImg1", splitValue);
        updateImage();
        break;
      case "blur":
        controller.blurSplit("saveImg", "saveImg1", splitValue);
        updateImage();
        break;
      case "sharpen":
        controller.sharpenSplit("saveImg", "saveImg1", splitValue);
        updateImage();
        break;
      case "luma":
        controller.lumaSplit("saveImg", "saveImg1", splitValue);
        updateImage();
        break;
      case "sepia":
        controller.sepiaSplit("saveImg", "saveImg1", splitValue);
        updateImage();
        break;
      case "dither":
        controller.ditherSplit("saveImg", "saveImg1", splitValue);
        updateImage();
        break;
      case "compression":

        if (!flag) {

          String input = JOptionPane.showInputDialog(SwingFeaturesFrame.this,
              "please input the percentage: ", "Input", JOptionPane.QUESTION_MESSAGE);
          percent = Integer.parseInt(input);
        }
        if (percent < 0 || percent > 100) {
          JOptionPane.showMessageDialog(SwingFeaturesFrame.this,
              "the value shall be >=0 and <=100", "Source", JOptionPane.PLAIN_MESSAGE);
        } else {

          controller.compressionSplit("saveImg", "saveImg1", splitValue, percent);
          updateImage();
        }
        break;
      case "adjustLevel":

        if (!flag) {

          JTextField bField = new JTextField(5);
          JTextField mField = new JTextField(5);
          JTextField wField = new JTextField(5);
          JPanel panel = new JPanel();
          panel.add(new JLabel("b value"));
          panel.add(bField);
          panel.add(Box.createHorizontalStrut(10));
          panel.add(new JLabel("m value"));
          panel.add(mField);
          panel.add(Box.createHorizontalStrut(10));
          panel.add(new JLabel("w value"));
          panel.add(wField);
          int bmw = JOptionPane.showConfirmDialog(null, panel,
              "Enter b,m,w value", JOptionPane.OK_CANCEL_OPTION);
          if (bmw == JOptionPane.OK_OPTION) {
            b = Integer.parseInt(bField.getText());
            m = Integer.parseInt(mField.getText());
            w = Integer.parseInt(wField.getText());
          }
        }
        if (b > m || m > w) {
          JOptionPane.showMessageDialog(SwingFeaturesFrame.this,
              "the value shall be b<m<w", "Source", JOptionPane.PLAIN_MESSAGE);
        } else {

          controller.levelAdjSplit(b, m, w, "saveImg", "saveImg1", splitValue);
          updateImage();
        }
        break;
      case "color-correct":
        controller.colorCorrectSplit("saveImg", "saveImg1", splitValue);
        updateImage();
        break;
      default:
        break;
    }
  }

  /**
   * This method is help to update image in the panel.
   */
  private void updateImage() {
    BufferedImage img = controller.getBufferedImage("saveImg1");
    BufferedImage histogramImg = controller.getHistogram("saveImg1");
    imageLabel[0].setIcon(new ImageIcon(img));
    imageLabel[1].setIcon(new ImageIcon(histogramImg));
    imagePanel.revalidate();
    imagePanel.repaint();
  }

  @Override
  public void valueChanged(ListSelectionEvent e) {
    //this is the override method.
  }


  /**
   * Invoked when an item has been selected or deselected by the user. The code written for this
   * method performs the operations that need to occur when an item is selected (or deselected).
   *
   * @param e the event to be processed
   */

  @Override
  public void itemStateChanged(ItemEvent e) {
    // return the event to be process
  }

  /**
   * Getter helper.
   *
   * @return get display of file
   */

  public JLabel getFileOpenDisplay() {
    return this.fileOpenDisplay;
  }

  /**
   * Getter helper.
   *
   * @return get display of file
   */

  public JLabel getFileSaveDisplay() {
    return this.fileSaveDisplay;
  }

  /**
   * Getter helper.
   *
   * @return get display of option
   */

  public JLabel getOptionDisplay() {
    return this.optionDisplay;
  }

  /**
   * Getter method for itemStateLabel.
   *
   * @return label
   */
  public JLabel getItemStateLabel() {
    return this.itemStateLabel;
  }

}
