package view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;


/**
 * A class to handle user input and output.
 */

public class ConsoleView implements IConsoleView {

  private final BufferedReader reader;
  private final Appendable appendable;

  /**
   * Constructs a ConsoleView with a given Readable for input and Appendable for output.
   * Throws IllegalArgumentException if either argument is null.
   *
   * @param readable   The input source, which is a Readable.
   * @param appendable The output destination, which is an Appendable.
   */

  public ConsoleView(Readable readable, Appendable appendable) {
    if (readable == null || appendable == null) {
      throw new IllegalArgumentException("Readable and Appendable cannot be null");
    }
    this.reader = new BufferedReader((Reader) readable);
    this.appendable = appendable;
  }


  @Override
  public void display(String message) throws IOException {
    appendable.append(message).append("\n");
  }


  @Override
  public String readLine() throws IOException {
    return reader.readLine();
  }

}