package view;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.geom.Path2D;
import java.awt.image.BufferedImage;


/**
 * Class to create a histogram image for RGB data.
 */
public class DisplayHistogram {

  /**
   * Creates a histogram image from the given RGB data.
   *
   * @param data The RGB data.
   * @return A BufferedImage representing the histogram.
   */
  public BufferedImage createHistogramImage(int[][] data) {
    final int width = 256;
    final int height = 256;
    BufferedImage histogramImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
    Graphics2D g2d = histogramImage.createGraphics();

    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

    drawBackgroundAndGrid(g2d);

    int max = findMaxValue(data);

    g2d.setStroke(new BasicStroke(1));

    Path2D redPath = new Path2D.Double();
    Path2D greenPath = new Path2D.Double();
    Path2D bluePath = new Path2D.Double();
    initializePath(redPath, greenPath, bluePath);

    for (int i = 0; i < 256; i++) {
      int redHeight = (int) ((data[0][i] / (double) max) * height);
      int greenHeight = (int) ((data[1][i] / (double) max) * height);
      int blueHeight = (int) ((data[2][i] / (double) max) * height);

      redPath.lineTo(i, height - redHeight);
      greenPath.lineTo(i, height - greenHeight);
      bluePath.lineTo(i, height - blueHeight);
    }

    g2d.setColor(Color.RED);
    g2d.draw(redPath);
    g2d.setColor(Color.GREEN);
    g2d.draw(greenPath);
    g2d.setColor(Color.BLUE);
    g2d.draw(bluePath);

    g2d.dispose();
    return histogramImage;
  }

  /**
   * Initializes the paths for the RGB histogram lines.
   */
  private void initializePath(Path2D redPath, Path2D greenPath, Path2D bluePath) {
    redPath.moveTo(0, 256);
    greenPath.moveTo(0, 256);
    bluePath.moveTo(0, 256);
  }

  /**
   * Finds the maximum value in the RGB data.
   *
   * @param data The RGB data.
   * @return The maximum value.
   */
  private int findMaxValue(int[][] data) {
    int max = 0;
    for (int i = 0; i < 256; i++) {
      max = Math.max(max, data[0][i]);
      max = Math.max(max, data[1][i]);
      max = Math.max(max, data[2][i]);
    }
    return max;
  }

  /**
   * Draws the background and grid for the histogram.
   *
   * @param g2d The Graphics2D object.
   */
  private void drawBackgroundAndGrid(Graphics2D g2d) {
    g2d.setColor(Color.WHITE);
    g2d.fillRect(0, 0, 256, 256);

    g2d.setColor(new Color(220, 220, 220));
    g2d.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL,
            0, new float[]{2}, 0));

    for (int i = 0; i < 256; i += 10) {
      g2d.drawLine(i, 0, i, 256);
    }

    for (int i = 0; i < 256; i += 10) {
      g2d.drawLine(0, i, 256, i);
    }
  }
}
