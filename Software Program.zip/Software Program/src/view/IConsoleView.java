package view;

import java.io.IOException;

/**
 * Interface of console View.
 */

public interface IConsoleView {

  /**
   * Displays a message to the user.
   *
   * @param message The message to be displayed.
   * @throws IOException if there is an issue with writing to the appendable.
   */

  void display(String message) throws IOException;


  /**
   * Reads a line of input from the user.
   *
   * @return A line of input as a String.
   * @throws IOException if there is an issue with reading from the reader.
   */

  String readLine() throws IOException;

}
