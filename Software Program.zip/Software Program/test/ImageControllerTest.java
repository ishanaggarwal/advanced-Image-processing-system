import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import controller.Command;
import controller.ImageController;
import model.FilePathHandle;
import model.ImageManipulator;
import view.ConsoleView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * A class to test Image controller.
 */

public class ImageControllerTest {

  private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
  private final PrintStream originalOut = System.out;
  private final InputStream originalIn = System.in;
  /**
   * A class to test Image controller.
   */

  ImageController controller;
  ImageManipulator manipulator;
  ConsoleView view;

  /**
   * Set up test.
   */

  @Before
  public void setUpStreams() {
    System.setOut(new PrintStream(outContent));
  }

  /**
   * After test.
   */

  @After
  public void restoreStreams() {
    System.setOut(originalOut);
    System.setIn(originalIn);
  }

  /**
   * Initial test.
   */

  @Before
  public void init() {
    manipulator = new ImageManipulator();
    view = new ConsoleView(new InputStreamReader(System.in), System.out);
    controller = new ImageController(manipulator, view);

  }

  /**
   * Test save.
   *
   * @throws IOException error processing
   */

  @Test
  public void testSaveImage() throws IOException {

    String inputFilename = "sample11.jpg";
    String outputFilename = "output-for-save.ppm";

    controller.load(inputFilename, "output111");
    controller.save(outputFilename, "output111");

    File outputFile = new File(FilePathHandle.getAbsolutePath(outputFilename));
    assertTrue(outputFile.exists());
  }

  /**
   * test flip horizontally.
   *
   * @throws IOException error processing
   */

  @Test
  public void filpHorizontally() throws IOException {
    String filename = "sample11.jpg";
    controller.load(filename, "output1");
    controller.filpHorizontally("output1", "output-for-flipHorizontally");
    controller.save("output-for-flipHorizontally.jpg", "output-for-flipHorizontally");
    controller.filpVertically("output-for-flipHorizontally", "output3");
    controller.save("output-for-flipHorizontally-vertical.jpg",
            "output-for-flipHorizontally");
    File outputFile = new File(FilePathHandle
            .getAbsolutePath("output-for-flipHorizontally-vertical.jpg"));
    assertTrue(outputFile.exists());
  }

  /**
   * Test flip vertically.
   *
   * @throws IOException error processing
   */

  @Test
  public void filpVertically() throws IOException {
    String filename = "sample11.jpg";
    controller.load(filename, "output1");
    controller.filpVertically("output1", "output3");
    controller.save("output-for-flipVertically.jpg", "output3");
    controller.filpHorizontally("output3", "output4");
    controller.save("output-for-flipVertically-Horizonal-.jpg", "output4");
    File outputFile = new File(FilePathHandle
            .getAbsolutePath("output-for-flipVertically-Horizonal-.jpg"));
    assertTrue(outputFile.exists());

  }

  /**
   * Test brighten.
   *
   * @throws IOException error processing
   */

  @Test
  public void brighten() throws IOException {
    String filename = "sample11.jpg";
    controller.load(filename, "output1");
    controller.brighten(50, "output1", "output4");
    controller.save("output-for-brighten-50.jpg", "output4");
    File outputFile = new File(FilePathHandle
            .getAbsolutePath("output-for-brighten-50.jpg"));
    assertTrue(outputFile.exists());


  }

  /**
   * Test darken.
   *
   * @throws IOException error processing
   */

  @Test
  public void darken() throws IOException {
    String filename = "sample11.jpg";
    controller.load(filename, "output1");
    controller.darken(50, "output1", "output5");
    controller.save("output-for-darken-50.jpg", "output5");
    File outputFile = new File(FilePathHandle.getAbsolutePath("output-for-darken-50.jpg"));
    assertTrue(outputFile.exists());
  }

  /**
   * Test split three color.
   *
   * @throws IOException error processing
   */

  @Test
  public void splitToThreeColorImages() throws IOException {
    String filename = "sample11.jpg";
    controller.load(filename, "output1");
    controller.rgbSplit("output1", "outputR", "outputG", "outputB");
    controller.save("output-for-red.jpg", "outputR");
    controller.save("output-for-green.jpg", "outputG");
    controller.save("output-for-blue.jpg", "outputB");
    File outputFile = new File(FilePathHandle.getAbsolutePath("output-for-blue.jpg"));
    assertTrue(outputFile.exists());
  }

  /**
   * Test combined.
   *
   * @throws IOException error processing
   */

  @Test
  public void combineToOneImage() throws IOException {
    String filename1 = "output-for-red.jpg";
    String filename2 = "output-for-green.jpg";
    String filename3 = "output-for-blue.jpg";
    controller.load(filename1, "outputR");
    controller.load(filename2, "outputG");
    controller.load(filename3, "outputB");
    controller.rgbCombine("outputR", "outputG", "outputB",
            "output-for-rgbCombine");
    controller.save("output-for-rgbCombine.jpg", "output-for-rgbCombine");
    File outputFile = new File(FilePathHandle.getAbsolutePath("output-for-rgbCombine.jpg"));
    assertTrue(outputFile.exists());
  }

  /**
   * Test blur.
   *
   * @throws IOException error processing
   */

  @Test
  public void blur() throws IOException {

    String filename = "sample11.jpg";
    controller.load(filename, "output1");
    controller.blur("output1", "output-for-blur1");
    controller.save("output-for-blur-1.jpg", "output-for-blur1");


    controller.blur("output-for-blur1", "output-for-blur2");
    controller.save("output-for-blur-2.jpg", "output-for-blur2");

    controller.blur("output-for-blur2", "output-for-blur3");
    controller.save("output-for-blur-3.jpg", "output-for-blur3");


    controller.blur("output-for-blur3", "output-for-blur4");
    controller.blur("output-for-blur4", "output-for-blur5");
    controller.blur("output-for-blur5", "output-for-blur6");
    controller.blur("output-for-blur6", "output-for-blur7");
    controller.save("output-for-blur-7.jpg", "output-for-blur7");
    File outputFile = new File(FilePathHandle.getAbsolutePath("output-for-blur-7.jpg"));
    assertTrue(outputFile.exists());


  }

  /**
   * Test sharpen.
   *
   * @throws IOException error processing
   */

  @Test
  public void sharpen() throws IOException {
    String filename = "sample11.jpg";
    controller.load(filename, "output1");

    controller.sharpen("output1", "output-for-sharpen");
    controller.sharpen("output-for-sharpen", "output-for-sharpen1");
    controller.save("output-for-sharpen-1.jpg", "output-for-sharpen1");
    controller.sharpen("output-for-sharpen1", "output-for-sharpen2");

    controller.save("output-for-sharpen-2.jpg", "output-for-sharpen2");
    File outputFile = new File(FilePathHandle.getAbsolutePath("output-for-sharpen-2.jpg"));
    assertTrue(outputFile.exists());

  }

  /**
   * Test sepia.
   *
   * @throws IOException error processing
   */

  @Test
  public void convertSepia() throws IOException {
    String filename = "sample11.jpg";
    controller.load(filename, "output1");

    controller.convertSepia("output1", "output-for-sepia");
    controller.save("output-for-sepia.jpg", "output-for-sepia");
    File outputFile = new File(FilePathHandle.getAbsolutePath("output-for-sepia.jpg"));
    assertTrue(outputFile.exists());


  }

  /**
   * Test  value component grey scale.
   *
   * @throws IOException error processing
   */

  @Test
  public void valueComponent() throws IOException {
    String filename = "sample11.jpg";
    controller.load(filename, "output1");
    controller.valueComponent("output1", "output-for-valueComponent");
    controller.save("output-for-valueComponent.jpg", "output-for-valueComponent");
    File outputFile = new File(FilePathHandle
            .getAbsolutePath("output-for-valueComponent.jpg"));
    assertTrue(outputFile.exists());

  }

  /**
   * Test intensity.
   *
   * @throws IOException error processing
   */

  @Test
  public void intensityComponent() throws IOException {
    String filename = "sample11.jpg";
    controller.load(filename, "output1");
    controller.intensityComponent("output1", "output9");
    controller.save("output-for-intensityComponent.jpg", "output9");
    File outputFile = new File(FilePathHandle.getAbsolutePath("output-for-intensityComponent.jpg"));
    assertTrue(outputFile.exists());

  }

  /**
   * test luma.
   *
   * @throws IOException error processing
   */

  @Test
  public void lumaComponent() throws IOException {
    String filename = "sample11.jpg";
    controller.load(filename, "output1");
    controller.lumaComponent("output1", "output10");
    controller.save("output-for-lumaComponent.jpg", "output10");
    File outputFile = new File(FilePathHandle.getAbsolutePath("output-for-lumaComponent.jpg"));
    assertTrue(outputFile.exists());

  }

  /**
   * Test compression.
   *
   * @throws IOException error processing
   */

  @Test
  public void compression() throws IOException {
    String filename = "koala-square.png";
    controller.load(filename, "output1");
    controller.compression(70, "output1", "output11");
    controller.save("koala-square-70.png", "output11");
    File outputFile = new File(FilePathHandle.getAbsolutePath("koala-square-70.png"));
    assertTrue(outputFile.exists());

  }

  /**
   * Test split.
   *
   * @throws IOException error processing
   */

  @Test
  public void splitTest() throws IOException {
    String filename = "sample11.png";
    controller.load(filename, "output1");
    controller.blurSplit("output1", "output12", 50);
    controller.save("blurSplit.png", "output12");
    File outputFile = new File(FilePathHandle.getAbsolutePath("blurSplit.png"));
    assertTrue(outputFile.exists());
  }

  /**
   * Test sharpen split.
   *
   * @throws IOException error processing
   */

  @Test
  public void splitSharpenTest() throws IOException {
    String filename = "sample11.png";
    controller.load(filename, "output1");
    controller.sharpenSplit("output1", "output12", 50);
    controller.save("sharpenSplit.png", "output12");
    File outputFile = new File(FilePathHandle.getAbsolutePath("sharpenSplit.png"));
    assertTrue(outputFile.exists());
  }

  /**
   * sepia split.
   *
   * @throws IOException error processing
   */

  @Test
  public void splitSepiaTest() throws IOException {
    String filename = "sample11.png";
    controller.load(filename, "output1");
    controller.sepiaSplit("output1", "output12", 50);
    controller.save("sepiaSplit.png", "output12");
    File outputFile = new File(FilePathHandle.getAbsolutePath("sepiaSplit.png"));
    assertTrue(outputFile.exists());
  }

  /**
   * Test greysclpe split.
   *
   * @throws IOException error processing
   */
  @Test
  public void splitGreyTest() throws IOException {
    String filename = "sample11.png";
    controller.load(filename, "output1");
    controller.greyscaleSplit("output1", "output12", 50);
    controller.save("greySplit.png", "output12");
    File outputFile = new File(FilePathHandle.getAbsolutePath("greySplit.png"));
    assertTrue(outputFile.exists());
  }

  /**
   * Test level adjust.
   *
   * @throws IOException error processing
   */

  @Test
  public void levelAdjTest() throws IOException {
    String filename = "sample11.png";
    controller.load(filename, "output1");
    controller.levelAdj(50, 100, 200, "output1", "output12");
    controller.save("levelAdjustment.png", "output12");
    File outputFile = new File(FilePathHandle.getAbsolutePath("levelAdjustment.png"));
    assertTrue(outputFile.exists());
  }

  /**
   * Test histogram.
   *
   * @throws IOException error processing
   */

  @Test
  public void histogramTest() throws IOException {
    String filename = "sample11.png";
    controller.load(filename, "output1");
    controller.histogram("output1", "outHistogram.png");
    File outputFile = new File(FilePathHandle.getAbsolutePath("outHistogram.png"));
    assertTrue(outputFile.exists());
  }

  /**
   * Test the color correction with histogram.
   *
   * @throws IOException error processing
   */
  @Test
  public void colorCorrectionComponent() throws IOException {
    String filename = "sample11.png";
    controller.load(filename, "output1");
    controller.colorCorrect("output1", "output10");
    controller.histogram("output10", "colorCorrectionHist.png");
    controller.save("colorCorrect.jpg", "output10");
    File outputFile = new File(FilePathHandle
            .getAbsolutePath("colorCorrect.jpg"));
    assertTrue(outputFile.exists());

  }

  /**
   * Test invalid command.
   */

  @Test
  public void testInvalidCommand() {

    Command invalidCommand = new Command("S", new ArrayList<>());

    try {
      controller.executeCommand(invalidCommand, view);
    } catch (IllegalArgumentException e) {
      assertEquals("s", e.getMessage());
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Test invalid file.
   */

  @Test
  public void testInvalidFile() {

    List<String> list = new ArrayList<>();
    list.add(0, "script");
    list.add(1, "sscriptrun1");
    Command invalidFile = new Command("run", list);

    try {
      controller.executeCommand(invalidFile, view);
    } catch (IllegalArgumentException e) {
      assertEquals("No File or Directory", e.getMessage());
    } catch (IOException e) {
      assertTrue(e.getMessage().contains("No File or Directory"));
      throw new RuntimeException(e);
    }
  }

  /**
   * Test running script.
   */

  @Test
  public void testRunScriptFile() throws IOException {

    String scriptFilePath = "script.txt";
    File scriptFile = new File(FilePathHandle.getAbsolutePath(scriptFilePath));
    assertTrue(scriptFile.exists());

    controller.runScript(scriptFilePath);
    File fileOut = new File(FilePathHandle.getAbsolutePath("outputImagewithScript.jpg"));
    assertTrue(fileOut.exists());
  }

  /**
   * test split color correction.
   *
   * @throws IOException error processing.
   */
  @Test
  public void splitCorrectTest() throws IOException {
    String filename = "sample11.png";
    controller.load(filename, "output1");
    controller.colorCorrectSplit("output1", "output12", 50);
    controller.save("colorCorrectSplit.png", "output12");
    File outputFile = new File(FilePathHandle.getAbsolutePath("colorCorrectSplit.png"));
    assertTrue(outputFile.exists());
  }

  /**
   * test split adjustment.
   *
   * @throws IOException error processing
   */
  @Test
  public void splitAdjustmentTest() throws IOException {
    String filename = "sample11.png";
    controller.load(filename, "output1");
    controller
            .levelAdjSplit(20, 100, 250,
                    "output1", "output12", 50);
    controller.save("levelAdjustmentSplit.png", "output12");
    File outputFile = new File(FilePathHandle.getAbsolutePath("levelAdjustmentSplit.png"));
    assertTrue(outputFile.exists());
  }
}
