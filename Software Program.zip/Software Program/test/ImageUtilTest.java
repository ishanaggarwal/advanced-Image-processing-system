import org.junit.Test;

import java.io.IOException;

import model.Image;
import imageio.ImageLoaderSaver;
import imageio.ImageUtil;

import static org.junit.Assert.assertEquals;

/**
 * A class to test image utility handling.
 */

public class ImageUtilTest {

  /**
   * this is test for read the PPM file.
   *
   * @throws IOException error processing.
   */
  @Test
  public void testReadPPM() throws IOException {
    String filename;
    filename = "ass4/res/sample.ppm";
    ImageLoaderSaver imageLoaderSaver = new ImageUtil();

    Image image = imageLoaderSaver.readPPM(filename);
    assertEquals(image.getWidth(), 4);
    for (int i = 0; i < image.getWidth(); i++) {
      for (int j = 0; j < image.getHeight(); j++) {
        int r = image.getImage()[i][j].getR();
        int g = image.getImage()[i][j].getG();
        int b = image.getImage()[i][j].getB();
        assertEquals(255, image.getValue()[i][j]);
        assertEquals(Math.round((r + g + b) / 3), image.getIntensity()[i][j]);
        assertEquals((int) Math.round(0.2126 * r + 0.7152 * g + 0.0722 * b), image.getLuma()[i][j]);
      }
    }
    imageLoaderSaver.saveImage(image, "output.ppm", "ppm");
  }

  /**
   * this is test for read the png or rpg file.
   *
   * @throws IOException error processing.
   */
  @Test
  public void testReadPNGAndJPG() throws IOException {
    String filename;
    filename = "sample11.png";
    ImageLoaderSaver imageLoaderSaver = new ImageUtil();
    Image image = imageLoaderSaver.readPNGAndJPG(filename);
    assertEquals(image.getWidth(), 500);
    for (int i = 0; i < image.getWidth(); i++) {
      for (int j = 0; j < image.getHeight(); j++) {
        int r = image.getImage()[i][j].getR();
        int g = image.getImage()[i][j].getG();
        int b = image.getImage()[i][j].getB();
        assertEquals(Math.max(r, Math.max(g, b)), image.getValue()[i][j]);
        assertEquals(Math.round((r + g + b) / 3), image.getIntensity()[i][j]);
        assertEquals((int) Math.round(0.2126 * r + 0.7152 * g + 0.0722 * b), image.getLuma()[i][j]);
      }
    }
    imageLoaderSaver.saveImage(image, "output.jpg", "jpg");
  }


}