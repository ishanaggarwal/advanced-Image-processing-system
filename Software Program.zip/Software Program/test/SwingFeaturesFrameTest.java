import org.junit.Before;
import org.junit.Test;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JCheckBox;
import javax.swing.SwingUtilities;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.ItemEvent;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

import javax.swing.event.ListSelectionEvent;

import controller.ImageController;
import model.ImageManipulator;
import view.SwingFeaturesFrame;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;


/**
 * A class to test GUI.
 */

public class SwingFeaturesFrameTest {

  /**
   * A class to test GUI.
   */

  private SwingFeaturesFrame frame;

  /**
   * Set up.
   */

  @Before
  public void setUp() throws InterruptedException, InvocationTargetException {
    frame = new SwingFeaturesFrame(new ImageController(new ImageManipulator()));
    frame.setVisible(true);
    // Ensure the frame is created on the Event Dispatch Thread
    SwingUtilities.invokeAndWait(() -> frame =
            new SwingFeaturesFrame(new ImageController(new ImageManipulator())));
    assertNotNull("Frame should not be null", frame);
  }

  /**
   * Simulate an action event and test the response.
   * @throws Exception when error
   */

  @Test
  public void testOpenFileButton() throws Exception {
    JButton openButton = findButtonWithActionCommand(frame, "Open file");
    assertNotNull("Open file button not found", openButton);

    // Simulate button click
    SwingUtilities.invokeAndWait(openButton::doClick);

    // Assert that the fileOpenDisplay label is updated with a file path
    assertFalse("File path label should be updated",
            frame.getFileOpenDisplay().getText().equals("File path will appear here"));
  }

  /**
   * Simulate an action event and test the response.
   * @throws Exception when error
   */


  @Test
  public void testSaveFileButton() throws Exception {
    JButton saveButton = findButtonWithActionCommand(frame, "Save file");
    assertNotNull("Save file button not found", saveButton);

    // Simulate button click
    SwingUtilities.invokeAndWait(saveButton::doClick);

    // Assert that the fileSaveDisplay label is updated with a file path
    assertFalse("File path label should be updated",
            frame.getFileSaveDisplay().getText().equals("File path will appear here"));
  }


  /**
   * Simulate an action event and test the response.
   * @throws Exception when error
   */

  @Test
  public void testOptionButton() throws Exception {
    JButton optionButton = findButtonWithActionCommand(frame, "Option");
    assertNotNull("Option button not found", optionButton);

    // Simulate button click
    SwingUtilities.invokeAndWait(optionButton::doClick);

    // Assert that the optionDisplay label is updated with the selected option
    assertTrue(frame.getOptionDisplay().getText().contains("flipVertical"));
  }


  /**
   *  Utility method to find a JButton by its action command in a container.
   */

  private JButton findButtonWithActionCommand(Container container, String command) {
    for (Component comp : container.getComponents()) {
      if (comp instanceof JButton) {
        JButton button = (JButton) comp;
        if (command.equals(button.getActionCommand())) {
          return button;
        }
      } else if (comp instanceof Container) {
        JButton button = findButtonWithActionCommand((Container) comp, command);
        if (button != null) {
          return button;
        }
      }
    }
    return null;
  }


  /**
   * Simulate a value change event and test the response.
   * @throws NoSuchFieldException No such file exception
   * @throws IllegalAccessException illegal Access exception
   */


  @Test
  public void testValueChanged() throws NoSuchFieldException, IllegalAccessException {
    // Access the private field using reflection
    Field listOfStringsField = SwingFeaturesFrame.class.getDeclaredField("listOfStrings");
    listOfStringsField.setAccessible(true);
    Object fieldObj = listOfStringsField.get(frame);

    if (!(fieldObj instanceof JList)) {
      fail("Field 'listOfStrings' is not an instance of JList");
    }

    @SuppressWarnings("unchecked")
    JList<String> listOfStrings = (JList<String>) fieldObj;

    assertNotNull("listOfStrings is null", listOfStrings);

    // Assuming the list is not empty and has predefined values
    listOfStrings.setSelectedIndex(0);

    // Now trigger the valueChanged method
    ListSelectionEvent event = new ListSelectionEvent(this,
            0,
            0,
            false);
    frame.valueChanged(event);

    // Access another private field for verification
    Field someLabelField = SwingFeaturesFrame.class.getDeclaredField("File path will appear here");
    someLabelField.setAccessible(true);
    JLabel someLabel = (JLabel) someLabelField.get(frame);

    assertNotNull("File path will appear here is null",
            someLabel);

    // Assert changes in the JLabel text
    assertEquals("Expected text based on selection",
            someLabel.getText());
  }

  /**
   * Simulate an item state change event and test the response.
   * @throws Exception  throw exception if error
   */

  @Test
  public void testItemStateChanged() throws Exception {

    assertNotNull("Frame should not be null before testing", frame);

    JLabel itemStateLabel = frame.getItemStateLabel();
    assertNotNull("itemStateLabel should not be null", itemStateLabel);

    // Initial state of the label
    String initialText = itemStateLabel.getText();

    // Simulate an item state change
    ItemEvent event = new ItemEvent(new JCheckBox(), ItemEvent.ITEM_STATE_CHANGED,
            null, ItemEvent.SELECTED);
    SwingUtilities.invokeAndWait(() -> frame.itemStateChanged(event));

    // Verify that the label text has been updated
    assertEquals(initialText, itemStateLabel.getText());
  }

}