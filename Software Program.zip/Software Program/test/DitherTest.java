import static org.junit.Assert.assertEquals;

import model.Image;
import model.ImageManipulator;
import model.Pixel;
import org.junit.Before;
import org.junit.Test;

/**
 * Tests for the "dither" operation.
 */
public class DitherTest {

  private ImageManipulator imageManipulator;
  private Image testImage;

  @Before
  public void setUp() {
    imageManipulator = new ImageManipulator();
  }

  @Test
  public void testDitherOperation3x3() {
    testImage = new Image(3, 3);

    var pixels = new Pixel[][]{
        {new Pixel(1, 2, 3), new Pixel(4, 5, 6), new Pixel(7, 8, 9)},
        {new Pixel(101, 102, 103), new Pixel(104, 105, 106), new Pixel(107, 108, 109)},
        {new Pixel(201, 202, 203), new Pixel(204, 205, 206), new Pixel(207, 208, 209)},

    };
    testImage.setImage(pixels);

    var res = imageManipulator.dither(testImage).getImage();
    var expected = new int[][][]{{{0, 0, 0}, {0, 0, 0}, {0, 0, 0}},
        {{0, 0, 0}, {255, 255, 255}, {0, 0, 0}},
        {{255, 255, 255}, {255, 255, 255}, {255, 255, 255}}};
    for (int i = 0; i < 3; ++i) {
      for (int j = 0; j < 3; ++j) {
        assertEquals(res[i][j].getR(), expected[i][j][0]);
        assertEquals(res[i][j].getG(), expected[i][j][1]);
        assertEquals(res[i][j].getB(), expected[i][j][2]);
      }
    }
  }

  @Test
  public void testDitherOperation4x4() {
    testImage = new Image(4, 4);

    var pixels = new Pixel[][]{
        {new Pixel(255, 0, 0), new Pixel(0, 255, 0), new Pixel(0, 0, 255),
            new Pixel(128, 128, 128)},
        {new Pixel(64, 128, 192), new Pixel(192, 128, 64), new Pixel(255, 255, 0),
            new Pixel(0, 255, 255)},
        {new Pixel(128, 64, 192), new Pixel(255, 0, 255), new Pixel(128, 192, 64),
            new Pixel(192, 192, 192)},
        {new Pixel(0, 128, 64), new Pixel(64, 0, 128), new Pixel(192, 64, 0), new Pixel(128, 0, 0)},
    };
    testImage.setImage(pixels);

    var res = imageManipulator.dither(testImage).getImage();
    var expected = new int[][][]
        {{{0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {255, 255, 255}},
            {{255, 255, 255}, {255, 255, 255}, {255, 255, 255}, {0, 0, 0}},
            {{0, 0, 0}, {255, 255, 255}, {0, 0, 0}, {255, 255, 255}},
            {{0, 0, 0}, {0, 0, 0}, {255, 255, 255}, {0, 0, 0}}};
    for (int i = 0; i < 4; ++i) {
      for (int j = 0; j < 4; ++j) {
        assertEquals(res[i][j].getR(), expected[i][j][0]);
        assertEquals(res[i][j].getG(), expected[i][j][1]);
        assertEquals(res[i][j].getB(), expected[i][j][2]);
      }
    }
  }

  @Test
  public void testDitherOperation5x5() {
    testImage = new Image(5, 5);

    var pixels = new Pixel[][]{
        {new Pixel(255, 0, 0), new Pixel(0, 255, 0), new Pixel(0, 0, 255), new Pixel(128, 128, 128),
            new Pixel(64, 192, 64)},
        {new Pixel(64, 128, 192), new Pixel(192, 128, 64), new Pixel(255, 255, 0),
            new Pixel(0, 255, 255), new Pixel(128, 0, 128)},
        {new Pixel(128, 64, 192), new Pixel(255, 0, 255), new Pixel(128, 192, 64),
            new Pixel(192, 192, 192), new Pixel(0, 0, 0)},
        {new Pixel(0, 128, 64), new Pixel(64, 0, 128), new Pixel(192, 64, 0), new Pixel(128, 0, 0),
            new Pixel(255, 255, 255)},
        {new Pixel(192, 128, 0), new Pixel(128, 192, 0), new Pixel(0, 128, 192),
            new Pixel(192, 0, 128), new Pixel(128, 0, 192)},
    };
    testImage.setImage(pixels);

    var res = imageManipulator.dither(testImage).getImage();
    var expected = new int[][][]
        {{{0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {255, 255, 255}, {0, 0, 0}},
            {{255, 255, 255}, {255, 255, 255}, {255, 255, 255}, {0, 0, 0}, {255, 255, 255}},
            {{0, 0, 0}, {255, 255, 255}, {0, 0, 0}, {255, 255, 255}, {0, 0, 0}},
            {{0, 0, 0}, {0, 0, 0}, {255, 255, 255}, {0, 0, 0}, {255, 255, 255}},
            {{255, 255, 255}, {0, 0, 0}, {0, 0, 0}, {255, 255, 255}, {0, 0, 0}}};
    for (int i = 0; i < 5; ++i) {
      for (int j = 0; j < 5; ++j) {
        assertEquals(res[i][j].getR(), expected[i][j][0]);
        assertEquals(res[i][j].getG(), expected[i][j][1]);
        assertEquals(res[i][j].getB(), expected[i][j][2]);
      }
    }
  }

}