import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;

import view.ConsoleView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

/**
 * A class to test viewing input message, respond, and display it.
 */

public class ConsoleViewTest {


  /**
   * A class to test console view process and handle user in/out put.
   */

  private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
  private final PrintStream originalOut = System.out;
  private final InputStream originalIn = System.in;


  /**
   * Set up test.
   */

  @Before
  public void setUpStreams() {
    System.setOut(new PrintStream(outContent));
  }

  /**
   * Before test.
   */

  @After
  public void restoreStreams() {
    System.setOut(originalOut);
    System.setIn(originalIn);
  }

  /**
   * Test basic initialization of ConsoleView.
   */

  @Test
  public void testBasicInitialization() {
    ConsoleView view = new ConsoleView(new InputStreamReader(System.in), System.out);
    assertNotNull(view);
  }

  /**
   * Test display message.
   *
   * @throws IOException when error displaying message
   */

  @Test
  public void testDisplayMessage() throws IOException {
    ConsoleView view = new ConsoleView(new InputStreamReader(System.in), System.out);

    view.display("Test message");
    assertEquals("Test message\n", outContent.toString());
  }

  /**
   * Read line.
   *
   * @throws IOException error when reading input
   */

  @Test
  public void testReadLine() throws IOException {

    String input = "User input\n";
    InputStream inContent = new ByteArrayInputStream(input.getBytes());
    System.setIn(inContent);

    ConsoleView view = new ConsoleView(new InputStreamReader(System.in), System.out);

    String userInput = view.readLine();
    assertEquals("User input", userInput);
  }

  /**
   * Test read multiple lines.
   *
   * @throws IOException error when reading input
   */

  @Test
  public void testReadLineMultipleLines() throws IOException {

    String input = "Line 1\nLine 2\nLine 3\n";
    InputStream inContent = new ByteArrayInputStream(input.getBytes());
    System.setIn(inContent);

    ConsoleView view = new ConsoleView(new InputStreamReader(System.in), System.out);

    String line1 = view.readLine();
    String line2 = view.readLine();
    String line3 = view.readLine();

    assertEquals("Line 1", line1);
    assertEquals("Line 2", line2);
    assertEquals("Line 3", line3);
  }


  /**
   * Test read empty.
   *
   * @throws IOException when error reading
   */

  @Test
  public void testReadLineEmptyInput() throws IOException {

    String input = "";
    InputStream inContent = new ByteArrayInputStream(input.getBytes());
    System.setIn(inContent);

    ConsoleView view = new ConsoleView(new InputStreamReader(System.in), System.out);

    String userInput = view.readLine();
    assertNull(userInput);
  }

  /**
   * Empty message display.
   */

  @Test
  public void testDisplayEmptyMessage() throws IOException {
    ConsoleView view = new ConsoleView(new InputStreamReader(System.in), System.out);

    view.display("");

    assertEquals("\n", outContent.toString());
  }


  /**
   * Display multiple message.
   */

  @Test
  public void testDisplayWithMultipleMessages() throws IOException {
    ConsoleView view = new ConsoleView(new InputStreamReader(System.in), System.out);

    view.display("Message 1");
    view.display("Message 2");
    view.display("Message 3");

    String expectedOutput = "Message 1\nMessage 2\nMessage 3\n";
    assertEquals(expectedOutput, outContent.toString());
  }

  /**
   * Test null.
   */

  @Test
  public void testInitializationWithNullReadable() {
    try {
      new ConsoleView(null, System.out);
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Readable and Appendable cannot be null", e.getMessage());
    }
  }

  /**
   * Test null.
   */

  @Test
  public void testInitializationWithNullAppendable() {
    try {
      new ConsoleView(new InputStreamReader(System.in), null);
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertEquals("Readable and Appendable cannot be null", e.getMessage());
    }
  }


  /**
   * test execution.
   */

  @Test
  public void testReadLineIOException() {
    InputStream customInputStream = new InputStream() {
      @Override
      public int read() throws IOException {
        throw new IOException("Custom IOException");
      }
    };

    try {
      System.setIn(customInputStream);

      ConsoleView view = new ConsoleView(new InputStreamReader(System.in), System.out);
      view.readLine();
      fail("Expected IOException");
    } catch (IOException e) {
      assertEquals("Custom IOException", e.getMessage());
    }
  }

}
