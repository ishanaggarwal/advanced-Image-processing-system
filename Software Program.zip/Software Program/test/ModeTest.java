
import org.junit.After;
import org.junit.Test;
import org.junit.Before;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import modehanlder.ModeHandler;
import model.FilePathHandle;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

/**
 * A class to test modes.
 */

public class ModeTest {

  /**
   *  class to test modes.
   */


  private ModeHandler modeHandler;

  private final InputStream systemIn = System.in;
  private final PrintStream systemOut = System.out;
  private ByteArrayOutputStream testOut;

  /**
   *  Helper class to test modes.
   */

  @Before
  public void setUpOutput() {
    testOut = new ByteArrayOutputStream();
    System.setOut(new PrintStream(testOut));
  }

  /**
   *  Helper class to test modes.
   */

  @Before
  public void setUp() {
    modeHandler = new ModeHandler();
  }

  /**
   *  Helper class to test modes.
   */

  private void provideInput(String data) {
    ByteArrayInputStream testIn = new ByteArrayInputStream(data.getBytes());
    System.setIn(testIn);
  }

  /**
   *  Helper class to test modes.
   */

  private String getOutput() {
    return testOut.toString();
  }

  /**
   *  Helper class to test modes.
   */

  @After
  public void restoreSystemInputOutput() {
    System.setIn(systemIn);
    System.setOut(systemOut);
  }

  /**
   *  Class to test mode commandline setup.
   */

  @Test
  public void testCommandLineMode() {
    provideInput("your simulated user input here\n");
    modeHandler.startApplication(new String[]{"-text"});
    assertTrue("Command line mode should be initialized",
            modeHandler.isCommandLineInitialized());
  }

  /**
   *  Class to test mode script file.
   */

  @Test
  public void testScriptFileMode() {
    modeHandler.startApplication(new String[]{"-file",
            FilePathHandle.getAbsolutePath("run script2.txt")});
    assertTrue("Script mode should be initialized",
            modeHandler.isScriptModeInitialized());
    assertFalse("GUI mode should not be initialized",
            modeHandler.isGuiInitialized());
    assertFalse("Command line mode should not be initialized",
            modeHandler.isCommandLineInitialized());
  }


  /**
   *  Class to test mode valid text command.
   */

  @Test
  public void testInteractiveTextMode() {
    provideInput("load sample11.png\ntest1\n");
    modeHandler.startApplication(new String[]{"-text"});
    assertTrue("Command line mode should be initialized",
            modeHandler.isCommandLineInitialized());
    assertFalse("GUI mode should not be initialized",
            modeHandler.isGuiInitialized());
    assertFalse("Script mode should not be initialized",
            modeHandler.isScriptModeInitialized());
  }

  /**
   *  Class to test mode invalid command and handle exception.
   */

  @Test
  public void testInvalidArguments() {
    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
      modeHandler.startApplication(new String[]{"-invalid"});
    });
    String expectedMessage = "Invalid command-line arguments.";
    String actualMessage = exception.getMessage();
    assertTrue(actualMessage.contains(expectedMessage));
    assertTrue("Error handling should be initialized",
            modeHandler.isInvalidArgumentsHandled());
  }

  /**
   *  Class to test mode GUI.
   */

  @Test
  public void testGraphicalUserInterfaceMode() {
    provideInput("your simulated user input here\n");
    modeHandler.startApplication(new String[] {});
    assertTrue("GUI mode should be initialized",
            modeHandler.isGuiInitialized());
    assertFalse("Command line mode should not be initialized",
            modeHandler.isCommandLineInitialized());
    assertFalse("Script mode should not be initialized",
            modeHandler.isScriptModeInitialized());
  }
}
